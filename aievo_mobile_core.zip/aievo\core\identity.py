import os
import base64
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.hazmat.primitives import serialization

class SovereignIdentity:
    """
    الهوية السيادية (Sovereign Identity): مسؤولة عن الهوية الرقمية وتوقيع الكود.
    """
    def __init__(self, key_path: str = "aievo/dna/sovereign.key"):
        self.key_path = key_path
        self.private_key, self.public_key = self._load_or_generate_keys()

    def _load_or_generate_keys(self):
        """تحميل المفاتيح الحالية أو توليد زوج مفاتيح جديد (Ed25519)."""
        if os.path.exists(self.key_path):
            with open(self.key_path, "rb") as f:
                private_key = serialization.load_pem_private_key(f.read(), password=None)
        else:
            os.makedirs(os.path.dirname(self.key_path), exist_ok=True)
            private_key = ed25519.Ed25519PrivateKey.generate()
            with open(self.key_path, "wb") as f:
                f.write(private_key.private_bytes(
                    encoding=serialization.Encoding.PEM,
                    format=serialization.PrivateFormat.PKCS8,
                    encryption_algorithm=serialization.NoEncryption()
                ))

        return private_key, private_key.public_key()

    def get_public_identity(self) -> str:
        """يعيد الهوية العامة (Public Key) كبصمة رقمية."""
        pub_bytes = self.public_key.public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )
        return base64.b64encode(pub_bytes).decode()

    def sign_content(self, content: str) -> str:
        """توقيع المحتوى (كود أو بيانات) رقمياً."""
        signature = self.private_key.sign(content.encode())
        return base64.b64encode(signature).decode()

    def verify_signature(self, content: str, signature_b64: str) -> bool:
        """التحقق من صحة التوقيع الرقمي للمحتوى."""
        try:
            signature = base64.b64decode(signature_b64)
            self.public_key.verify(signature, content.encode())
            return True
        except Exception:
            return False

    def generate_proof_of_code(self, code: str) -> str:
        """توليد وسم 'إثبات الكود' (Proof of Code) ليتم إدراجه في الملفات."""
        identity = self.get_public_identity()
        sig = self.sign_content(code)
        return f"# AIEVO-PROOF: {identity[:16]}... | SIG: {sig[:32]}..."
