import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """
    إعدادات النظام (System Configuration): تدير مفاتيح API ونماذج الذكاء الاصطناعي.
    """
    # العقول الخارجية
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

    # المحرك المحلي (Ollama)
    OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    LOCAL_MODEL = "llama3" # أو "deepseek-coder"

    # إعدادات الذاكرة
    REDIS_HOST = "localhost"
    REDIS_PORT = 6379
