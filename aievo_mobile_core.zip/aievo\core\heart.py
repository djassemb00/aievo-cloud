import os

from .sentinel import Sentinel

class Heart:
    """
    القلب (Heart): المسؤول عن تنفيذ التعديلات الفعلية على الملفات مع حماية النسخ الاحتياطي المشفر.
    """
    def __init__(self, project_root: str):
        self.project_root = project_root
        self.backups_dir = os.path.join(project_root, "aievo/memory/backups")
        self.sentinel = Sentinel() # تهيئة الحارس للتشفير
        os.makedirs(self.backups_dir, exist_ok=True)

    def create_backup(self, file_path: str, encrypted: bool = False):
        """إنشاء نسخة احتياطية من ملف (عادية أو مشفرة)."""
        full_path = os.path.join(self.project_root, file_path)
        if os.path.exists(full_path):
            backup_name = f"{os.path.basename(file_path)}.{int(os.path.getmtime(full_path))}"
            if encrypted:
                backup_name += ".aes"
                self.sentinel.secure_backup(full_path)
                # نقل الملف المشفر لمجلد النسخ الاحتياطية
                import shutil
                shutil.move(full_path + ".aes", os.path.join(self.backups_dir, backup_name))
            else:
                backup_name += ".bak"
                import shutil
                shutil.copy2(full_path, os.path.join(self.backups_dir, backup_name))

            print(f"🛡️ [Heart] تم إنشاء نسخة احتياطية {'مشفرة' if encrypted else ''}: {backup_name}")
            return os.path.join(self.backups_dir, backup_name)
        return None

    def apply_patch(self, file_path: str, new_content: str, use_backup: bool = False):
        """
        تطبيق التعديل على ملف معين.
        """
        if use_backup:
            self.create_backup(file_path)

        full_path = os.path.join(self.project_root, file_path)
        print(f"💓 نبض: تعديل الملف {file_path}")

        # التأكد من وجود المجلد
        os.makedirs(os.path.dirname(full_path), exist_ok=True)

        with open(full_path, "w", encoding="utf-8") as f:
            f.write(new_content)

        return True
