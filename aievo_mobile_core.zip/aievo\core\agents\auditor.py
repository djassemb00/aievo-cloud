from typing import Dict, Any

class AuditorAgent:
    """
    وكيل التدقيق (Auditor Agent):
    المسؤول عن مراجعة الكود المكتوب بحثاً عن ثغرات أمنية، أخطاء منطقية، أو مخالفة للمعايير.
    """
    def __init__(self, brain):
        self.brain = brain

    def review(self, code: str, test: str, task: str, signature: str = None, identity_manager: Any = None, ethics_manager: Any = None) -> Dict[str, Any]:
        print("🕵️ [Auditor] جاري تدقيق الكود والتحقق من الهوية والأخلاق...")

        # 1. التحقق من التوقيع الرقمي
        identity_verified = False
        if signature and identity_manager:
            identity_verified = identity_manager.verify_signature(code, signature)
            if not identity_verified:
                print("⚠️ [Auditor] تحذير: فشل التحقق من التوقيع الرقمي للكود!")

        # 2. التحقق من المواءمة الأخلاقية
        ethics_verified = True
        ethics_feedback = ""
        if ethics_manager:
            alignment = ethics_manager.check_alignment(task, code)
            ethics_verified = alignment['is_aligned']
            ethics_feedback = alignment['feedback']

        prompt = f"""
        أنت مدقق أمني وخبير جودة كود (Security Auditor & QA Expert).
        المهمة: {task}
        الحالة الأمنية للهوية: {"موثقة ✅" if identity_verified else "غير موثقة ❌"}
        الحالة الأخلاقية: {"متوافقة ✅" if ethics_verified else "تنبيه أخلاقي ⚠️"}
        ملاحظات الأخلاق: {ethics_feedback}

        الكود المولد:
        ```python
        {code}
        ```
        الاختبار المولد:
        ```python
        {test}
        ```

        المطلوب:
        قم بتقييم الكود والاختبار. هل هما آمنان؟ هل يحققان المطلوب بكفاءة؟
        إذا وجدت أي مشكلة (ثغرة، خطأ منطقي، تعقيد غير مبرر)، ارفض الكود واشرح السبب.

        تنسيق الرد:
        القرار: [مقبول / مرفوض]
        الملاحظات: [اشرح رأيك هنا]
        التعديلات المطلوبة: [إذا كان مرفوضاً، ماذا يجب أن يفعل المبرمج؟]
        """

        ai_response = self.brain.think(prompt, level="auto")

        is_accepted = (("مقبول" in ai_response.split('\n')[0] or "Accepted" in ai_response.upper()) and ethics_verified)

        return {
            "is_accepted": is_accepted,
            "feedback": ai_response,
            "decision": "Accepted" if is_accepted else "Rejected"
        }
