import datetime
import json
import os
from typing import Dict, Any, List

class SovereignIoTMaster:
    """
    محرك التحكم بالأشياء السيادي (Sovereign IoT Master):
    المسؤول عن إدارة الأجهزة المادية والتحكم بها.
    """
    def __init__(self, project_root: str):
        self.project_root = project_root
        self.registry_path = os.path.join(project_root, "aievo/memory/iot_registry.json")
        self.devices = self._load_registry()

    def _load_registry(self) -> List[Dict[str, Any]]:
        """تحميل سجل الأجهزة المتصلة."""
        if os.path.exists(self.registry_path):
            with open(self.registry_path, "r", encoding="utf-8") as f:
                return json.load(f)
        # أجهزة افتراضية أولية (Mock)
        return [
            {"id": "fan-01", "name": "مروحة التبريد", "type": "actuator", "status": "off", "room": "Server-Room"},
            {"id": "light-01", "name": "إضاءة المختبر", "type": "actuator", "status": "on", "room": "Lab"},
            {"id": "temp-sensor-01", "name": "مستشعر الحرارة", "type": "sensor", "value": 25.0, "unit": "°C", "room": "Server-Room"}
        ]

    def _save_registry(self):
        """حفظ سجل الأجهزة."""
        with open(self.registry_path, "w", encoding="utf-8") as f:
            json.dump(self.devices, f, indent=4, ensure_ascii=False)

    def set_device_status(self, device_id: str, status: str, authorized: bool = False) -> Dict[str, Any]:
        """تغيير حالة جهاز (تشغيل/إيقاف)."""
        if not authorized:
            return {"status": "FAILED", "reason": "UNAUTHORIZED", "message": "تغيير الحالة المادية يتطلب تفويضاً."}

        for dev in self.devices:
            if dev["id"] == device_id:
                dev["status"] = status
                dev["last_action"] = datetime.datetime.now().isoformat()
                self._save_registry()
                print(f"🔌 [IoT] تم تغيير حالة {dev['name']} إلى {status}")
                return {"status": "SUCCESS", "device": dev}

        return {"status": "FAILED", "reason": "NOT_FOUND"}

    def get_sensor_data(self, device_id: str) -> Dict[str, Any]:
        """جلب بيانات من مستشعر معين."""
        for dev in self.devices:
            if dev["id"] == device_id and dev["type"] == "sensor":
                return {"status": "SUCCESS", "data": dev}
        return {"status": "FAILED", "reason": "NOT_FOUND"}

    def get_all_devices(self) -> List[Dict[str, Any]]:
        return self.devices
