from .evolved_logic import *

def test_process(): assert process() == True