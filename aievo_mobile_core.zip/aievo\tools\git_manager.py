import subprocess
import os

class GitManager:
    """
    مدير Git: مسؤول عن تأريخ التطور الذاتي للنظام.
    """
    def __init__(self, project_root: str):
        self.project_root = project_root
        self._is_git = os.path.exists(os.path.join(project_root, ".git"))

    def commit_change(self, message: str):
        """توثيق التعديلات الحالية."""
        if not self._is_git:
            print("⚠️ [GitManager] مستودع Git غير مهيأ. تخطي الـ Commit.")
            return False

        try:
            print(f"🗄️ [GitManager] توثيق التغيير: {message}")
            subprocess.run(["git", "add", "."], cwd=self.project_root, check=True)
            subprocess.run(["git", "commit", "-m", f"AIEVO: {message}"], cwd=self.project_root, check=True)
            return True
        except Exception as e:
            print(f"❌ فشل عملية Git: {e}")
            return False

    def create_branch(self, branch_name: str):
        """إنشاء فرع جديد لتجربة ميزة."""
        if not self._is_git: return False
        try:
            subprocess.run(["git", "checkout", "-b", branch_name], cwd=self.project_root, check=True)
            return True
        except:
            return False
