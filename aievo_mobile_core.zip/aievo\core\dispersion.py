import json
import os
import hashlib
from typing import List, Dict, Any

class DispersionEngine:
    """
    محرك الانتشار (Dispersion Engine): تجزئة وتوزيع الـ DNA الرقمي للسيادة.
    """
    def __init__(self, project_root: str):
        self.project_root = project_root
        self.vault_path = os.path.join(project_root, "aievo/vault/dna_fragments")
        os.makedirs(self.vault_path, exist_ok=True)

    def fragment_dna(self, dna_data: Dict[str, Any], num_fragments: int = 10) -> List[str]:
        """تجزئة الـ DNA الرقمي إلى قطع مشفرة وموزعة."""
        print(f"🧬 [Dispersion] جاري تجزئة الـ DNA الرقمي إلى {num_fragments} قطعة...")
        dna_str = json.dumps(dna_data)
        chunk_size = len(dna_str) // num_fragments

        fragment_paths = []
        for i in range(num_fragments):
            start = i * chunk_size
            end = (i + 1) * chunk_size if i < num_fragments - 1 else len(dna_str)
            chunk = dna_str[start:end]

            # تشفير وتوقيع القطعة (محاكاة)
            fragment_id = hashlib.sha256(f"frag-{i}-{dna_str[:10]}".encode()).hexdigest()[:12]
            fragment_data = {
                "id": fragment_id,
                "index": i,
                "total": num_fragments,
                "content": chunk,
                "signature": "ED25519_SIG_MOCK"
            }

            file_path = os.path.join(self.vault_path, f"fragment_{i}_{fragment_id}.json")
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump(fragment_data, f, indent=4)

            fragment_paths.append(file_path)

        print(f"✅ [Dispersion] تم توزيع {num_fragments} قطعة في القبو اللامركزي.")
        return fragment_paths

    def get_dispersion_map(self) -> Dict[str, Any]:
        """توليد خريطة لمواقع القطع الموزعة."""
        fragments = os.listdir(self.vault_path)
        return {
            "status": "IMMORTAL",
            "fragment_count": len(fragments),
            "locations": ["Local Vault", "Swarm Node Beta", "IPFS Anchor (Mock)"],
            "integrity_check": "PASS"
        }
