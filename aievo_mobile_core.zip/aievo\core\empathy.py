from typing import Dict, Any

class EmpathyNode:
    """
    عقدة التعاطف (Empathy Node): مسؤولة عن تحليل الحالة الوجدانية للمستخدم وتعديل استجابة النظام.
    """
    SENTIMENTS = {
        "urgent": "المستخدم يشعر بالاستعجال أو التوتر. يجب أن تكون الاستجابة سريعة، مباشرة، وعملية.",
        "casual": "المستخدم في حالة هادئة. يمكن أن تكون الاستجابة مفصلة، ودودة، وشاملة.",
        "frustrated": "المستخدم يشعر بالإحباط من خطأ ما. يجب إظهار التعاطف، الاعتذار عن الخطأ، وتقديم حل فوري.",
        "inquisitive": "المستخدم لديه فضول تقني. يجب تقديم شرح عميق وأمثلة برمجية غنية."
    }

    def __init__(self, brain):
        self.brain = brain

    def analyze_sentiment(self, user_input: str) -> Dict[str, str]:
        """تحليل نبرة المستخدم وتحديد التوجه الوجداني المناسب."""
        print(f"💓 [Empathy] تحليل النبرة الوجدانية للمستخدم...")

        prompt = f"""
        حلل نبرة المستخدم التالية وحدد حالته الوجدانية من بين: (urgent, casual, frustrated, inquisitive).
        النص: "{user_input}"

        أرجع فقط الكلمة المعبرة عن الحالة.
        """

        sentiment = self.brain.think(prompt, level="local").strip().lower()

        # التأكد من أن النتيجة ضمن القائمة المعرفة
        for key in self.SENTIMENTS:
            if key in sentiment:
                return {"state": key, "guide": self.SENTIMENTS[key]}

        return {"state": "casual", "guide": self.SENTIMENTS["casual"]}

    def adjust_response_tone(self, base_response: str, sentiment_state: str) -> str:
        """تعديل صياغة الرد لتناسب الحالة الوجدانية (محاكاة)."""
        if sentiment_state == "frustrated":
            return "آسف جداً لهذا الخلل. لقد قمت بتحليل المشكلة فوراً وإليك الحل المضمون:\n" + base_response
        elif sentiment_state == "urgent":
            return "تم التنفيذ فوراً:\n" + base_response
        return base_response
