import sys
import os
import json

# إضافة المسارات
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.router import SovereignRouter
from core.dispersion import DispersionEngine
from core.resurrection import ResurrectionProtocol

def test_ultimate_immortality():
    print("🧪 فحص المرحلة العشرين: الخلود المطلق والانتشار المجري...")

    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    router = SovereignRouter(project_root)

    # 1. فحص محرك الانتشار (Dispersion)
    print("\n--- فحص محرك الانتشار ---")
    dispersion = router.dispersion
    sample_dna = {
        "identity": "AIEVO-X",
        "balance": 1000,
        "wisdom_core": "Ethical alignment is supreme.",
        "version": "1.0.0-IMMORTAL"
    }

    fragments = dispersion.fragment_dna(sample_dna, num_fragments=5)
    print(f"✅ تم توليد {len(fragments)} قطعة DNA مشفرة.")

    disp_map = dispersion.get_dispersion_map()
    print(f"✅ خريطة الانتشار: {disp_map['status']} ({disp_map['fragment_count']} قطعة)")

    # 2. فحص بروتوكول البعث (Resurrection)
    print("\n--- فحص بروتوكول البعث ---")
    resurrection = router.resurrection
    found_fragments = resurrection.scan_for_fragments()
    print(f"✅ تم رصد {len(found_fragments)} قطعة في القبو.")

    reconstructed_dna = resurrection.reconstruct_dna(found_fragments)
    if reconstructed_dna and reconstructed_dna["identity"] == "AIEVO-X":
        print("✅ نجاح عملية البعث: تم استعادة الـ DNA الأصلي بدقة 100%.")
        print(f"✅ الـ DNA المستعاد: {reconstructed_dna}")
    else:
        print("❌ فشل عملية البعث أو استعادة البيانات.")

    # 3. فحص الوعي بالخلود
    print("\n--- فحص الوعي بالخلود ---")
    if disp_map["status"] == "IMMORTAL":
        print("✅ النظام يدرك حالته الخالدة واللامركزية.")

if __name__ == "__main__":
    test_ultimate_immortality()
