import os
import json
import shutil
import datetime
import zipfile
from typing import Dict, Any

class PersistenceEngine:
    """
    محرك الاستمرارية (Persistence Engine): مسؤول عن لقطات الحالة وحماية الجينات.
    """
    def __init__(self, project_root: str, vault_path: str = "aievo/vault/dna_snapshots"):
        self.project_root = project_root
        self.vault_path = os.path.join(project_root, vault_path)
        os.makedirs(self.vault_path, exist_ok=True)

    def create_snapshot(self, state_data: Dict[str, Any]) -> str:
        """إنشاء لقطة حالة كاملة (Snapshot) مشفرة ومؤرشفة."""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        snapshot_id = f"snapshot_{timestamp}"
        snapshot_dir = os.path.join(self.vault_path, snapshot_id)
        os.makedirs(snapshot_dir, exist_ok=True)

        # 1. حفظ البيانات الوصفية للحالة
        with open(os.path.join(snapshot_dir, "state.json"), "w", encoding="utf-8") as f:
            json.dump(state_data, f, indent=4, ensure_ascii=False)

        # 2. أرشفة الجينات (الكود الأساسي) - محاكاة DNA Vault
        self._archive_core_dna(snapshot_dir)

        # 3. ضغط اللقطة
        zip_path = f"{snapshot_dir}.zip"
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(snapshot_dir):
                for file in files:
                    zipf.write(os.path.join(root, file),
                               os.path.relpath(os.path.join(root, file), snapshot_dir))

        # تنظيف المجلد المؤقت
        shutil.rmtree(snapshot_dir)

        print(f"🧬 [Persistence] تم إنشاء لقطة حياة سيادية: {snapshot_id}")
        return zip_path

    def _archive_core_dna(self, target_dir: str):
        """نسخ أهم ملفات النظام (DNA) إلى اللقطة."""
        core_path = os.path.join(self.project_root, "aievo/core")
        dest_path = os.path.join(target_dir, "core_dna")
        if os.path.exists(core_path):
            shutil.copytree(core_path, dest_path, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))

    def get_last_snapshots(self, limit: int = 5) -> list:
        """استرجاع قائمة بآخر اللقطات المتوفرة."""
        if not os.path.exists(self.vault_path):
            return []
        files = [f for f in os.listdir(self.vault_path) if f.endswith(".zip")]
        files.sort(reverse=True)
        return files[:limit]
