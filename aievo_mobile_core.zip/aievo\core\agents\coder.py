from typing import Dict, Any

class CoderAgent:
    """
    وكيل البرمجة (Coder Agent):
    المسؤول عن كتابة الكود الفعلي واختبارات الوحدة بناءً على خطة المهندس المعماري.
    """
    def __init__(self, brain):
        self.brain = brain

    def implement(self, current_step: str, context: str = "") -> Dict[str, str]:
        print(f"💻 [Coder] جاري تنفيذ الخطوة: {current_step}")

        prompt = f"""
        أنت مبرمج خبير (Senior Developer).
        الخطوة الحالية المراد تنفيذها: {current_step}
        سياق إضافي: {context}

        المطلوب:
        1. اكتب الكود البرمجي اللازم داخل علامات ```python.
        2. اكتب اختبار وحدة (Unit Test) شامل داخل علامات ```test.
        اجعل الكود نظيفاً، فعالاً، وموثقاً.
        """

        ai_response = self.brain.think(prompt, level="auto")

        # استخراج الكود والاختبار
        code = ""
        test = ""

        if "```python" in ai_response:
            code = ai_response.split("```python")[1].split("```")[0].strip()

        if "```test" in ai_response:
            test = ai_response.split("```test")[1].split("```")[0].strip()
        elif "```python" in ai_response and ai_response.count("```python") > 1:
            test = ai_response.split("```python")[2].split("```")[0].strip()

        return {"code": code, "test": test, "raw_response": ai_response}
