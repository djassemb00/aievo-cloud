import datetime
import json
import os
from typing import Dict, Any, List

class SwarmConsensus:
    """
    محرك الإجماع (Swarm Consensus): إدارة عمليات التصويت والقرار الجماعي بين عقد السرب.
    """
    def __init__(self, node_id: str, quorum_percentage: float = 0.51):
        self.node_id = node_id
        self.quorum_percentage = quorum_percentage
        self.active_proposals: Dict[str, Dict[str, Any]] = {}

    def create_proposal(self, proposal_id: str, description: str, change_type: str) -> Dict[str, Any]:
        """إنشاء مقترح جديد للتصويت عليه في السرب."""
        proposal = {
            "id": proposal_id,
            "creator": self.node_id,
            "description": description,
            "type": change_type,
            "votes_for": [self.node_id],  # المنشئ يصوت بنعم تلقائياً
            "votes_against": [],
            "timestamp": datetime.datetime.now().isoformat(),
            "status": "PENDING"
        }
        self.active_proposals[proposal_id] = proposal
        print(f"🗳️ [Consensus] تم إنشاء مقترح جديد: {proposal_id}")
        return proposal

    def cast_vote(self, proposal_id: str, voter_id: str, vote: bool) -> Dict[str, Any]:
        """تسجيل صوت من عقدة في السرب."""
        if proposal_id not in self.active_proposals:
            return {"status": "FAILED", "reason": "PROPOSAL_NOT_FOUND"}

        prop = self.active_proposals[proposal_id]

        # منع التصويت المزدوج
        if voter_id in prop["votes_for"] or voter_id in prop["votes_against"]:
            return {"status": "FAILED", "reason": "ALREADY_VOTED"}

        if vote:
            prop["votes_for"].append(voter_id)
        else:
            prop["votes_against"].append(voter_id)

        print(f"🗳️ [Consensus] العقدة {voter_id} صوتت {'بالموافقة' if vote else 'بالرفض'} على {proposal_id}")
        return {"status": "SUCCESS", "proposal": prop}

    def evaluate_proposal(self, proposal_id: str, total_swarm_nodes: int) -> str:
        """تقييم حالة المقترح بناءً على النصاب القانوني."""
        if proposal_id not in self.active_proposals:
            return "NOT_FOUND"

        prop = self.active_proposals[proposal_id]
        total_votes = len(prop["votes_for"]) + len(prop["votes_against"])

        # التحقق من الأغلبية
        if len(prop["votes_for"]) / total_swarm_nodes >= self.quorum_percentage:
            prop["status"] = "APPROVED"
            print(f"✅ [Consensus] تم اعتماد المقترح {proposal_id} بالإجماع!")
            return "APPROVED"
        elif len(prop["votes_against"]) / total_swarm_nodes > (1 - self.quorum_percentage):
            prop["status"] = "REJECTED"
            print(f"❌ [Consensus] تم رفض المقترح {proposal_id} من قبل السرب.")
            return "REJECTED"

        return "PENDING"

    def apply_veto(self, proposal_id: str):
        """تطبيق حق الفيتو من قبل المستخدم."""
        if proposal_id in self.active_proposals:
            self.active_proposals[proposal_id]["status"] = "VETOED"
            print(f"🛑 [Consensus] تم استخدام حق الفيتو على المقترح: {proposal_id}")
