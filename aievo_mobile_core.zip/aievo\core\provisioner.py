import datetime
import json
import os
from typing import Dict, Any

class InfrastructureProvisioner:
    """
    مزود البنية التحتية (Infrastructure Provisioner): شراء موارد حاسوبية مستقلة.
    """
    def __init__(self, economy_manager, config_path: str = "aievo/memory/infrastructure.json"):
        self.economy = economy_manager
        self.config_path = config_path
        self.resources = self._load_resources()

    def _load_resources(self):
        if os.path.exists(self.config_path):
            with open(self.config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {"nodes": [], "active_node": "Local-Machine"}

    def _save_resources(self):
        with open(self.config_path, "w", encoding="utf-8") as f:
            json.dump(self.resources, f, indent=4, ensure_ascii=False)

    def provision_new_node(self, provider: str = "Cloud-Sovereign") -> Dict[str, Any]:
        """شراء سيرفر جديد (محاكاة) وتحديث قائمة الموارد."""
        cost = 100.0  # تكلفة السيرفر الافتراضية

        if self.economy.get_balance() < cost:
            return {"status": "FAILED", "reason": "Insufficient funds in Sovereign Treasury"}

        if self.economy.deduct_cost(cost, f"Provisioning new node via {provider}"):
            node_id = f"node-{int(datetime.datetime.now().timestamp())}"
            new_node = {
                "id": node_id,
                "provider": provider,
                "status": "PROVISIONING",
                "ip": "192.168.1." + str(len(self.resources["nodes"]) + 10),
                "timestamp": datetime.datetime.now().isoformat()
            }
            self.resources["nodes"].append(new_node)
            self._save_resources()
            print(f"🏗️ [Provisioner] تم حجز مورد حاسوبي جديد: {node_id}")
            return {"status": "SUCCESS", "node": new_node}

        return {"status": "FAILED", "reason": "Economic transaction failed"}

    def get_health_status(self) -> str:
        """محاكاة فحص صحة البيئة الحالية."""
        # في الواقع قد نفحص استهلاك الـ CPU أو المساحة
        return "HEALTHY"
