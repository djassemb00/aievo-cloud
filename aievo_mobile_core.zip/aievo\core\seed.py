import datetime
from typing import List, Dict, Any

class SimplicityGene:
    """
    جين البساطة: يضمن أن الكود المولد يظل نظيفاً ومفهوماً.
    """
    MAX_COMPLEXITY_SCORE = 10

    @staticmethod
    def evaluate_complexity(code: str) -> float:
        """
        تقييم بسيط لتعقيد الكود (سيتم تطويره لاحقاً باستخدام AST).
        حالياً يعتمد على طول الدوال وعدد المتغيرات.
        """
        lines = code.split('\n')
        score = len(lines) / 20.0 # كل 20 سطر تزيد نقطة
        return score

class NewbornMind:
    """
    العقل المولود (Newborn Mind): بذرة التطور والتعلم السيادي.
    """
    def __init__(self, owner: str = "المستخدم"):
        self.identity = {
            "name": "AIEVO Seed",
            "version": "1.0.0-Alpha",
            "birth_date": datetime.datetime.now().isoformat(),
            "owner": owner
        }
        self.instincts = {
            "curiosity": 0.9,  # الرغبة في الاستكشاف
            "caution": 0.7,    # الحذر من الأخطاء (نظام المناعة)
            "simplicity": 0.95 # تقديس البساطة (قانون السيادة)
        }
        self.experiences: List[Dict[str, Any]] = []
        self.knowledge_graph = {}

    def perceive(self, project_summary: str):
        """إدراك البيئة المحيطة (الكود المصدري)"""
        print(f"🧬 [Seed] إدراك البيئة: {project_summary[:100]}...")

    def reflect(self, proposal: str) -> bool:
        """
        التأمل: هل هذا التعديل يتوافق مع جينات البساطة؟
        """
        complexity = SimplicityGene.evaluate_complexity(proposal)
        if complexity > SimplicityGene.MAX_COMPLEXITY_SCORE:
            print(f"⚠️ [Seed] رفض التعديل: التعقيد ({complexity}) يتجاوز الحدود المسموحة.")
            return False
        return True

    def learn(self, task: str, success: bool, feedback: str):
        """تسجيل تجربة جديدة للنمو"""
        entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "task": task,
            "success": success,
            "feedback": feedback
        }
        self.experiences.append(entry)
        print(f"🧠 [Seed] تم تعلم درس جديد: {task} -> {'نجاح' if success else 'فشل'}")

    def get_status(self):
        return {
            "age_in_experiences": len(self.experiences),
            "dominant_instinct": max(self.instincts, key=self.instincts.get),
            "sovereignty_status": "Secure"
        }
