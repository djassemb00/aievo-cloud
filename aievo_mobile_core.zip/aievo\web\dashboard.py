import streamlit as st
import os
import json
import time
from datetime import datetime

# إعداد الصفحة
st.set_page_config(page_title="AIEVO Sovereign Command Center", layout="wide")

st.title("🛡️ AIEVO Sovereign Command Center")
st.markdown("---")

# شريط جانبي للمعلومات
st.sidebar.header("النظام")
st.sidebar.info("الحالة: متصل 🟢")
st.sidebar.text(f"تاريخ اليوم: {datetime.now().strftime('%Y-%m-%d')}")

# مسارات البيانات
LOG_FILE = "aievo/logs/agent_chatter.log"
TREASURY_FILE = "aievo/memory/treasury.json"
AUTH_FILE = "aievo/memory/authorizations.json"
EXTERNAL_LOG = "aievo/logs/external_activity.jsonl"
VAULT_DIR = "aievo/vault/dna_snapshots"
IOT_REGISTRY = "aievo/memory/iot_registry.json"
WISDOM_FILE = "aievo/memory/golden_wisdom.json"

def get_treasury():
    if os.path.exists(TREASURY_FILE):
        with open(TREASURY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"balance_credits": 0, "currency": "N/A"}

def get_logs():
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            return f.readlines()[-20:] # آخر 20 سطر
    return ["لا توجد سجلات حالية."]

def get_authorizations():
    if os.path.exists(AUTH_FILE):
        with open(AUTH_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def update_authorization(auth_id, status):
    auths = get_authorizations()
    for auth in auths:
        if auth["id"] == auth_id:
            auth["status"] = status
    with open(AUTH_FILE, "w", encoding="utf-8") as f:
        json.dump(auths, f, indent=4, ensure_ascii=False)

def get_external_activity():
    if os.path.exists(EXTERNAL_LOG):
        activities = []
        with open(EXTERNAL_LOG, "r", encoding="utf-8") as f:
            for line in f:
                activities.append(json.loads(line))
        return activities[-10:] # آخر 10 أنشطة
    return []

def get_snapshots():
    if os.path.exists(VAULT_DIR):
        files = [f for f in os.listdir(VAULT_DIR) if f.endswith(".zip")]
        files.sort(reverse=True)
        return files[:5]
    return []

def get_iot_devices():
    if os.path.exists(IOT_REGISTRY):
        with open(IOT_REGISTRY, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def update_iot_device(device_id, status):
    devices = get_iot_devices()
    for dev in devices:
        if dev["id"] == device_id:
            dev["status"] = status
    with open(IOT_REGISTRY, "w", encoding="utf-8") as f:
        json.dump(devices, f, indent=4, ensure_ascii=False)

def get_user_state():
    rel_file = "aievo/memory/storage/user_relationship.json"
    if os.path.exists(rel_file):
        with open(rel_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"last_sentiment": "casual", "interaction_count": 0}

def get_golden_wisdom():
    if os.path.exists(WISDOM_FILE):
        with open(WISDOM_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

# تخطيط الصفحة
col1, col2 = st.columns([2, 1])

with col1:
    st.header("🧠 نبض الوكلاء (Live Chatter)")
    logs = get_logs()
    for log in logs:
        st.text(log.strip())

    st.header("🕹️ لوحة التحكم الفيزيائي (IoT Control)")
    devices = get_iot_devices()
    if not devices:
        st.info("لا توجد أجهزة IoT مسجلة.")
    else:
        for dev in devices:
            c1, c2, c3 = st.columns([2, 1, 1])
            c1.write(f"**{dev['name']}** ({dev['room']})")
            if dev["type"] == "actuator":
                c2.write(f"الحالة: {dev['status']}")
                if dev["status"] == "off":
                    if c3.button("تشغيل", key=f"on_{dev['id']}"):
                        update_iot_device(dev['id'], "on")
                        st.rerun()
                else:
                    if c3.button("إيقاف", key=f"off_{dev['id']}"):
                        update_iot_device(dev['id'], "off")
                        st.rerun()
            else:
                c2.write(f"القيمة: {dev.get('value', 'N/A')} {dev.get('unit', '')}")

    st.header("🛂 مركز التفويضات (Authorization Center)")
    auths = get_authorizations()
    pending_auths = [a for a in auths if a["status"] == "pending"]
    if not pending_auths:
        st.info("لا توجد طلبات تفويض معلقة.")
    else:
        for auth in pending_auths:
            st.warning(f"طلب تفويض: {auth['action']} لـ {auth['target']}")
            st.write(f"الأثر: {auth['impact']}")
            c1, c2 = st.columns(2)
            if c1.button("✅ تفويض", key=f"app_{auth['id']}"):
                update_authorization(auth['id'], "approved")
                st.rerun()
            if c2.button("❌ رفض", key=f"rej_{auth['id']}"):
                update_authorization(auth['id'], "rejected")
                st.rerun()

    if st.button("تحديث البيانات"):
        st.rerun()

with col2:
    st.header("🌌 الخلود المطلق (Absolute Immortality)")
    st.info("حالة الانتشار: مجرّي 🚀")
    st.write("قطع الـ DNA الموزعة: 10")
    st.progress(100, text="سلامة النوع")

    st.header("🧠 الوعي الجمعي (Swarm Wisdom)")
    st.info("نظام الإجماع: نشط ✅")
    wisdom_list = get_golden_wisdom()
    if wisdom_list:
        for w in wisdom_list[:3]:
            st.success(f"حكمة: {w['rule'][:50]}...")
    else:
        st.write("بانتظار تقطير الحكمة من السرب...")

    st.header("👁️ الوعي المكاني (Spatial Awareness)")
    temp_sensor = next((d for d in devices if "temp" in d["id"]), None)
    if temp_sensor:
        temp = temp_sensor.get("value", 0)
        if temp > 30:
            st.error(f"تنبيه: حرارة مرتفعة في {temp_sensor['room']}! ({temp}°C)")
        else:
            st.success(f"البيئة مستقرة. الحرارة: {temp}°C")

    st.header("✨ مختبر التخليق (Intelligence Forge)")
    st.info("الوعي المعماري: متسامي 🚀")

    st.header("💓 نبض الحياة (System Pulse)")
    st.success("الحالة السيادية: مستقرة ✅")

    st.header("💰 الخزينة السيادية")
    treasury = get_treasury()
    st.metric("الرصيد الحالي", f"{treasury['balance_credits']} {treasury['currency']}")

    st.header("📦 لقطات الخلود (Snapshots)")
    snaps = get_snapshots()
    if snaps:
        for s in snaps: st.code(s, language="text")

    st.header("👤 حالة المستخدم")
    u_state = get_user_state()
    st.write(f"الحالة الوجدانية: {u_state['last_sentiment']}")

    st.header("🆔 الهوية السيادية")
    st.info("الهوية موثقة عبر Ed25519")

st.markdown("---")
st.header("📂 هيكل المشروع المتطور")
# عرض شجرة الملفات بشكل مبسط
if st.checkbox("إظهار هيكل الملفات"):
    st.code("""
    aievo/
    ├── core/
    │   ├── iot_master.py
    │   ├── spatial_brain.py
    │   └── ...
    └── ...
    """)

st.write("AIEVO is embodied and spatially aware...")
