from typing import Dict, Any, Type

class EphemeralAgent:
    """تمثيل لوكيل مؤقت متخصص يتم تخليقه لمهمة واحدة."""
    def __init__(self, name: str, specialty: str, brain: Any):
        self.name = name
        self.specialty = specialty
        self.brain = brain

    def execute(self, task: str, context: str = "") -> str:
        print(f"✨ [Ephemeral Agent: {self.name}] يعمل على تخصص: {self.specialty}")
        prompt = f"بصفتك خبيراً في {self.specialty}، قم بحل التالي: {task}\nContext: {context}"
        return self.brain.think(prompt, level="local")

class AgentSpawner:
    """
    مفرخ الوكلاء (Agent Spawner): تخليق وإدارة الوكلاء المتخصصين اللحظيين.
    """
    def __init__(self, brain, economy_manager):
        self.brain = brain
        self.economy = economy_manager
        self.active_agents: Dict[str, EphemeralAgent] = {}

    def spawn_specialist(self, specialty: str) -> EphemeralAgent:
        """تخليق وكيل متخصص جديد."""
        cost = 5.0  # تكلفة التخليق
        if self.economy.deduct_cost(cost, f"Spawning specialized agent: {specialty}"):
            agent_name = f"Specialist-{specialty.split()[-1]}-{len(self.active_agents) + 1}"
            agent = EphemeralAgent(agent_name, specialty, self.brain)
            self.active_agents[agent_name] = agent
            print(f"🐣 [Spawner] تم تخليق وكيل متخصص جديد: {agent_name}")
            return agent
        return None

    def absorb_and_terminate(self, agent_name: str, memory_manager: Any):
        """امتصاص خبرة الوكيل وحذفه لتوفير الموارد."""
        if agent_name in self.active_agents:
            agent = self.active_agents.pop(agent_name)
            print(f"🧹 [Spawner] تم امتصاص خبرة {agent_name} وإنهاء خدمته.")
            # تسجيل الخبرة في الذاكرة الرئيسية
            memory_manager.record_experience(
                task=f"Specialized Task: {agent.specialty}",
                result="Success",
                lesson=f"Insights gained from specialized agent in {agent.specialty}."
            )
