import json
import os
from datetime import datetime

class SovereignEconomy:
    """
    الاقتصاد السيادي (Sovereign Economy): مسؤول عن إدارة الخزينة والميزانية.
    """
    def __init__(self, treasury_path: str = "aievo/memory/treasury.json"):
        self.treasury_path = treasury_path
        self.state = self._load_treasury()

    def _load_treasury(self):
        """تحميل حالة الخزينة من الملف."""
        if os.path.exists(self.treasury_path):
            with open(self.treasury_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {
            "balance_credits": 1000.0,  # رصيد ابتدائي افتراضي
            "currency": "AI-Credits",
            "transactions": [],
            "last_updated": datetime.now().isoformat()
        }

    def _save_treasury(self):
        """حفظ حالة الخزينة."""
        self.state["last_updated"] = datetime.now().isoformat()
        with open(self.treasury_path, "w", encoding="utf-8") as f:
            json.dump(self.state, f, indent=4, ensure_ascii=False)

    def deduct_cost(self, amount: float, reason: str):
        """خصم تكلفة من الخزينة."""
        if self.state["balance_credits"] >= amount:
            self.state["balance_credits"] -= amount
            self.state["transactions"].append({
                "type": "DEBIT",
                "amount": amount,
                "reason": reason,
                "timestamp": datetime.now().isoformat()
            })
            self._save_treasury()
            print(f"💰 [Economy] خصم {amount} {self.state['currency']} | السبب: {reason}")
            return True
        return False

    def get_balance(self):
        return self.state["balance_credits"]

    def is_budget_ok(self, threshold: float = 10.0):
        """التحقق من كفاية الميزانية للقيام بمهام جديدة."""
        return self.state["balance_credits"] >= threshold
