import datetime
import json
import os
from typing import Dict, Any

class SovereignEnvoy:
    """
    المفوض السيادي (Sovereign Envoy): المسؤول عن التمثيل الخارجي والمراسلات.
    """
    def __init__(self, identity_manager, activity_log_path: str = "aievo/logs/external_activity.jsonl"):
        self.identity = identity_manager
        self.activity_log_path = activity_log_path
        os.makedirs(os.path.dirname(self.activity_log_path), exist_ok=True)

    def _log_activity(self, destination: str, action: str, content: str, status: str):
        """تسجيل النشاط الخارجي في السجل."""
        entry = {
            "timestamp": datetime.datetime.now().isoformat(),
            "destination": destination,
            "action": action,
            "content_summary": content[:100],
            "status": status,
            "signature": self.identity.sign_content(content) if status == "SENT" else None
        }
        with open(self.activity_log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

    def send_external_message(self, destination: str, message: str, authorized: bool = False) -> Dict[str, Any]:
        """إرسال رسالة خارجية (محاكاة) بعد التأكد من التفويض."""
        if not authorized:
            self._log_activity(destination, "SEND_MESSAGE", message, "BLOCKED_WAITING_AUTH")
            return {"status": "FAILED", "reason": "UNAUTHORIZED", "message": "المهمة تتطلب تفويضاً صريحاً من المالك."}

        # محاكاة الإرسال
        print(f"🚀 [Envoy] إرسال رسالة موثقة إلى {destination}...")
        self._log_activity(destination, "SEND_MESSAGE", message, "SENT")

        return {
            "status": "SUCCESS",
            "destination": destination,
            "content": message,
            "signature": self.identity.sign_content(message)
        }

    def prepare_delegation_report(self, action: str, target: str, impact: str) -> str:
        """إعداد تقرير تفويض للمستخدم للموافقة عليه."""
        return f"""
        📜 تقرير تفويض سيادي:
        العمل المطلوب: {action}
        الجهة المستهدفة: {target}
        الأثر المتوقع: {impact}
        حالة التوقيع: بانتظار تفويضك الرقمي...
        """
