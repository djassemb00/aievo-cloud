import subprocess
import socket

def check_ollama():
    """التحقق من وجود محرك Ollama."""
    try:
        subprocess.run(["ollama", "--version"], capture_output=True, check=True)
        return True
    except:
        return False

def check_redis():
    """التحقق من وجود خدمة Redis."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        s.connect(("localhost", 6379))
        s.close()
        return True
    except:
        return False

def print_system_status():
    print("\n🔍 فحص حالة البيئة المحيطة:")
    print(f"  - Ollama: {'✅ متصل' if check_ollama() else '❌ غير متاح'}")
    print(f"  - Redis: {'✅ متصل' if check_redis() else '❌ غير متاح'}")
