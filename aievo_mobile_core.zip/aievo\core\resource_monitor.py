import psutil
import time
from typing import Dict, Any

class ResourceMonitor:
    """
    مراقب الموارد (Resource Monitor): مسؤول عن مراقبة استهلاك الجهاز وتكلفة الـ AI.
    """
    def __init__(self):
        self.start_time = time.time()
        self.total_tokens_used = 0
        self.estimated_cost_usd = 0.0

    def get_system_metrics(self) -> Dict[str, Any]:
        """جلب مقاييس استهلاك الجهاز الحالي."""
        cpu_usage = psutil.cpu_percent(interval=1)
        memory_info = psutil.virtual_memory()

        return {
            "cpu_percent": cpu_usage,
            "memory_percent": memory_info.percent,
            "memory_used_gb": round(memory_info.used / (1024**3), 2),
            "uptime_seconds": round(time.time() - self.start_time, 2)
        }

    def track_ai_usage(self, model_name: str, prompt_tokens: int, completion_tokens: int):
        """تتبع استهلاك الـ Tokens وحساب التكلفة التقديرية."""
        self.total_tokens_used += (prompt_tokens + completion_tokens)

        # أسعار تقديرية (GPT-4o كمثال)
        cost_per_1k = 0.01 # $0.01 لكل 1000 توكن
        step_cost = ((prompt_tokens + completion_tokens) / 1000) * cost_per_1k
        self.estimated_cost_usd += step_cost

        print(f"💰 [ResourceMonitor] استهلاك AI: {prompt_tokens + completion_tokens} توكن | التكلفة التراكمية: ${self.estimated_cost_usd:.4f}")

    def get_economy_report(self) -> Dict[str, Any]:
        """تقرير الجدوى الاقتصادية للنظام."""
        return {
            "total_tokens": self.total_tokens_used,
            "total_cost_usd": round(self.estimated_cost_usd, 4),
            "efficiency_score": "High" if self.estimated_cost_usd < 1.0 else "Normal"
        }
