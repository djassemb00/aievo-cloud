import ast

class ImmuneSystem:
    """
    نظام المناعة (Immune System): فحص الكود والتبعيات قبل التنفيذ.
    """
    def __init__(self):
        # قائمة بالكلمات أو المكتبات المحظورة
        self.blacklist = ["os.remove", "shutil.rmtree", "subprocess.Popen", "os.system"]
        # قائمة المكتبات المسموح بتثبيتها (Whitelist)
        self.allowed_packages = ["numpy", "pandas", "requests", "pytest", "matplotlib", "scipy"]
        self.risk_threshold = 0.7

    def is_package_safe(self, package_name: str) -> bool:
        """التحقق من سلامة المكتبة المطلوبة."""
        print(f"🛡️ [ImmuneSystem] فحص سلامة المكتبة: {package_name}...")
        return package_name.lower() in self.allowed_packages

    def calculate_blast_radius(self, code: str) -> float:
        """
        حساب نطاق الانفجار (Blast Radius): تقييم خطورة التعديل.
        0.0 (آمن جداً) إلى 1.0 (حرج/مدمر).
        """
        risk_score = 0.0

        # 1. فحص الكلمات المحظورة
        for item in self.blacklist:
            if item in code:
                risk_score += 0.5

        # 2. فحص الوصول للملفات الحساسة
        sensitive_patterns = ["core/", "seed.py", "sovereignty.py", ".env"]
        for pattern in sensitive_patterns:
            if pattern in code:
                risk_score += 0.4

        # 3. فحص التعقيد المعماري (عدد الاستيرادات)
        if "import " in code:
            risk_score += (code.count("import ") * 0.05)

        return min(risk_score, 1.0)

    def scan_code(self, code: str) -> bool:
        """
        فحص الكود بحثاً عن عمليات خطيرة وتقييم المخاطر.
        """
        print("🛡️ [ImmuneSystem] فحص الكود المقترح...")

        # التحقق من نطاق الانفجار
        blast_radius = self.calculate_blast_radius(code)
        print(f"☢️ نطاق الانفجار (Blast Radius): {blast_radius:.2f}")

        if blast_radius > self.risk_threshold:
            print(f"🛑 [ImmuneSystem] رفض التعديل: مخاطر عالية جداً ({blast_radius})!")
            return False

        try:
            ast.parse(code) # التأكد من سلامة السينتكس
            print("✅ [ImmuneSystem] الكود سليم وجاهز للتجربة.")
            return True
        except Exception as e:
            print(f"⚠️ [ImmuneSystem] خطأ في بنية الكود: {str(e)}")
            return False
