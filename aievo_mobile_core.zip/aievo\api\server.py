from fastapi import FastAPI
from pydantic import BaseModel
import sys
import os

# إضافة المسارات
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.router import SovereignRouter

app = FastAPI(title="AIEVO Sovereign API")

# تهيئة الموجه
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
router = SovereignRouter(project_root)

class Query(BaseModel):
    prompt: str

@app.get("/")
def read_root():
    return {"status": "Sovereign API is active", "system": "AIEVO"}

@app.post("/think")
def think(query: Query):
    initial_state = {
        "messages": [query.prompt],
        "next_step": "",
        "current_code_map": {},
        "plan": [],
        "plan_index": 0,
        "is_safe": False,
        "retry_count": 0,
        "last_error": "",
        "proposed_code": "",
        "proposed_test": ""
    }
    result = router.run(initial_state)
    return {"response": result['messages'][-1]}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
