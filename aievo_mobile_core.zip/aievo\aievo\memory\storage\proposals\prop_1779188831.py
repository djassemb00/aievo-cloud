def part_1():
    return "Handled first 30 lines"

def part_2():
    return "Handled next 30 lines"

def refactored_function():
    part_1()
    part_2()