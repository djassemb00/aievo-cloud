import os
import ast
from typing import Dict, List, Any

class SelfMirror:
    """
    محرك "مرآة الذات" (Self-Mirror): المسؤول عن تحليل الكود المصدري للنظام
    وبناء خريطة معرفية (Code Map) تتيح للنظام فهم هيكليته.
    """
    def __init__(self, root_dir: str):
        self.root_dir = root_dir
        self.code_map = {}

    def scan_project(self) -> Dict[str, Any]:
        """
        يقوم بمسح المشروع وتحليل ملفات Python لاستخراج الدوال والأصناف.
        """
        project_structure = {}
        for root, _, files in os.walk(self.root_dir):
            if "__pycache__" in root or ".git" in root:
                continue

            relative_path = os.path.relpath(root, self.root_dir)
            if relative_path == ".":
                relative_path = "root"

            project_structure[relative_path] = []
            for file in files:
                if file.endswith(".py"):
                    file_path = os.path.join(root, file)
                    analysis = self._analyze_file(file_path)
                    project_structure[relative_path].append({
                        "filename": file,
                        "analysis": analysis
                    })

        self.code_map = project_structure
        return project_structure

    def _analyze_file(self, file_path: str) -> Dict[str, Any]:
        """
        تحليل ملف واحد باستخدام مكتبة ast لاستخراج المكونات البرمجية والتحقق من جودة الكود.
        """
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()
            try:
                tree = ast.parse(content)
            except Exception as e:
                return {"error": f"Failed to parse: {str(e)}"}

        classes = []
        functions = []
        imports = []
        issues = []

        # تحليل الأسطر
        lines = content.splitlines()

        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                methods = []
                for n in node.body:
                    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        methods.append(n.name)
                        method_len = n.end_lineno - n.lineno if hasattr(n, "end_lineno") else 0
                        if method_len > 50:
                            issues.append(f"⚠️ الدالة '{n.name}' في الصنف '{node.name}' طويلة جداً ({method_len} سطر).")

                classes.append({
                    "name": node.name,
                    "methods": methods,
                    "line_count": node.end_lineno - node.lineno if hasattr(node, "end_lineno") else 0
                })
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                func_len = node.end_lineno - node.lineno if hasattr(node, "end_lineno") else 0
                if func_len > 50:
                    issues.append(f"⚠️ الدالة '{node.name}' طويلة جداً ({func_len} سطر).")
                functions.append({"name": node.name, "line_count": func_len})

            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        imports.append(alias.name)
                else:
                    if node.module:
                        imports.append(node.module)

        return {
            "classes": classes,
            "functions": functions,
            "imports": list(set(imports)),
            "issues": issues,
            "raw_content": content
        }

    def get_summary(self) -> str:
        """
        يعيد ملخصاً نصياً للهيكلية مع التنبيهات المعمارية.
        """
        summary = "🏛️ ملخص الوعي المعماري لنظام AIEVO:\n"
        all_issues = []

        for folder, files in self.code_map.items():
            summary += f"\n📁 المجلد: {folder}\n"
            for file in files:
                summary += f"  - 📄 {file['filename']}\n"
                analysis = file['analysis']

                if analysis.get('issues'):
                    all_issues.extend([f"{file['filename']}: {i}" for i in analysis['issues']])

                for cls in analysis.get('classes', []):
                    summary += f"    - 🏛️ صنف: {cls['name']} ({len(cls['methods'])} دالة)\n"
                for func in analysis.get('functions', []):
                    summary += f"    - ⚙️ دالة: {func['name']}\n"

        if all_issues:
            summary += "\n⚠️ تنبيهات معمارية (Architectural Smells):\n"
            for issue in all_issues:
                summary += f"  - {issue}\n"

        return summary
