from typing import Dict, Any, List

class SpatialBrain:
    """
    الدماغ المكاني (Spatial Brain): تحليل الحواس والبيئة الفيزيائية.
    """
    def __init__(self, iot_master):
        self.iot = iot_master
        self.spatial_map = {}

    def analyze_environment(self) -> Dict[str, Any]:
        """تحليل حالة البيئة بناءً على كافة المستشعرات المتاحة."""
        print(f"👁️ [Spatial] تحليل السياق المكاني والبيئي...")
        devices = self.iot.get_all_devices()

        analysis = {
            "temperature_status": "NORMAL",
            "security_status": "SECURE",
            "active_rooms": set(),
            "alerts": []
        }

        for dev in devices:
            if dev["type"] == "sensor":
                if "temp" in dev["id"]:
                    temp = dev.get("value", 0)
                    if temp > 40.0:
                        analysis["temperature_status"] = "CRITICAL"
                        analysis["alerts"].append(f"حرارة عالية جداً في {dev['room']}: {temp}°C")
                    elif temp > 30.0:
                        analysis["temperature_status"] = "WARNING"

            analysis["active_rooms"].add(dev["room"])

        analysis["active_rooms"] = list(analysis["active_rooms"])
        return analysis

    def detect_anomalies(self, sensory_input: Dict[str, Any]) -> bool:
        """رصد أي شذوذ في البيانات الحسية (محاكاة)."""
        # إذا كانت هناك حركة غير متوقعة أو تغير مفاجئ في الحرارة
        return False
