import os
import operator
import json
from datetime import datetime
from typing import TypedDict, Annotated, List, Union
from langgraph.graph import StateGraph, END
from .brain import Brain
from .heart import Heart
from .immune_system import ImmuneSystem
from sandbox.manager import SandboxManager
from memory.manager import MemoryManager

class AgentState(TypedDict):
    """
    حالة الوكيل (Agent State): تخزن مسار التفكير والقرارات المتخذة.
    """
    messages: Annotated[List[str], operator.add]
    next_step: str
    current_code_map: dict
    plan: List[str]
    plan_index: int   # تتبع الخطوة الحالية في الخطة
    is_safe: bool
    recent_memories: str
    retry_count: int  # تتبع عدد محاولات الإصلاح
    last_error: str   # تخزين آخر خطأ برمي لرصده
    proposed_code: str
    proposed_test: str
    proposed_signature: str

from .dreaming import DreamingModule
from .sovereignty import SovereigntyCharter
from .seed import NewbornMind
from tools.web_search import WebSearchTool
from tools.env_manager import EnvManager
from tools.git_manager import GitManager
from .agents.architect import ArchitectAgent
from .agents.coder import CoderAgent
from .agents.auditor import AuditorAgent
from .genetic_lab import GeneticLab
from .sentinel import Sentinel
from .vision_node import VisionNode
from .self_mirror import SelfMirror
from .swarm_sync import SwarmSync
from .resource_monitor import ResourceMonitor
from .iot_master import SovereignIoTMaster
from .spatial_brain import SpatialBrain
from .identity import SovereignIdentity
from .economy import SovereignEconomy
from .ethics import EthicsCharter
from .empathy import EmpathyNode
from .envoy import SovereignEnvoy
from .negotiator import AutonomousNegotiator
from .persistence import PersistenceEngine
from .provisioner import InfrastructureProvisioner
from .synthesis import SynthesisEngine
from .spawner import AgentSpawner
from .consensus import SwarmConsensus
from .distiller import WisdomDistiller
from .dispersion import DispersionEngine
from .resurrection import ResurrectionProtocol

class SovereignRouter:
    """
    الموجه السيادي (Sovereign Router): يدير دورة حياة التفكير والتطوير الذاتي
    باستخدام طاقم من الوكلاء، الهوية، الاقتصاد، والبوصلة الأخلاقية.
    """
    def __init__(self, project_root: str):
        self.project_root = project_root
        self.log_file = os.path.join(project_root, "aievo/logs/agent_chatter.log")
        self.brain = Brain(provider="mock")
        self.heart = Heart(project_root)
        self.immune_system = ImmuneSystem()
        self.sandbox = SandboxManager(project_root)
        self.memory = MemoryManager(project_root)
        self.mirror = SelfMirror(project_root)

        # تهيئة المكونات السيادية والمتقدمة
        self.sentinel = Sentinel()
        self.genetic_lab = GeneticLab(self.brain, self.mirror, self.heart, self.sandbox)
        self.vision_node = VisionNode(self.brain)

        # المرحلة 12: السرب، الموارد، وIoT
        self.swarm = SwarmSync(node_id="Master-Node-01")
        self.monitor = ResourceMonitor()

        # المرحلة 18: التجسد السيادي والوعي بالأشياء (تطوير للمرحلة 12)
        self.iot_master = SovereignIoTMaster(project_root)
        self.spatial_brain = SpatialBrain(self.iot_master)

        # المرحلة 13: الهوية والاقتصاد
        self.identity = SovereignIdentity()
        self.economy = SovereignEconomy()

        # المرحلة 14: الأخلاق والتعاطف
        self.ethics = EthicsCharter(self.brain)
        self.empathy = EmpathyNode(self.brain)

        # المرحلة 15: الوكالة السيادية والتمثيل الرقمي
        self.envoy = SovereignEnvoy(self.identity)
        self.negotiator = AutonomousNegotiator(self.brain, self.ethics)
        self.authorizations_path = os.path.join(project_root, "aievo/memory/authorizations.json")

        # المرحلة 16: الخلود السيادي والاستمرارية
        self.persistence = PersistenceEngine(project_root)
        self.provisioner = InfrastructureProvisioner(self.economy)
        self.pulse_status = "STABLE"

        # المرحلة 17: التسامي المعماري والتخليق
        self.synthesis = SynthesisEngine(self.brain)
        self.spawner = AgentSpawner(self.brain, self.economy)
        self.dynamic_path = []

        # المرحلة 19: التفرد والذكاء الجمعي
        self.consensus = SwarmConsensus(self.swarm.node_id)
        self.distiller = WisdomDistiller(self.brain)

        # المرحلة 20: الخلود المطلق والانتشار المجري
        self.dispersion = DispersionEngine(project_root)
        self.resurrection = ResurrectionProtocol(os.path.join(project_root, "aievo/vault/dna_fragments"))

        # تهيئة الوكلاء المتخصصين
        self.architect = ArchitectAgent(self.brain)
        self.coder = CoderAgent(self.brain)
        self.auditor = AuditorAgent(self.brain)

        # تهيئة الأدوات
        self.web_search = WebSearchTool()
        self.env_manager = EnvManager(project_root)
        self.git_manager = GitManager(project_root)

        # إضافة البذرة، الميثاق ووحدة الأحلام
        self.seed = NewbornMind(owner="المستخدم")
        self.sovereignty = SovereigntyCharter(owner_name="المستخدم")
        self.dream_unit = DreamingModule(
            self.brain, self.heart, self.immune_system, self.sandbox, self.memory
        )

        self.workflow = StateGraph(AgentState)
        self._build_graph()

    def _build_graph(self):
        # تعريف العقد (Nodes)
        self.workflow.add_node("analyze", self.analyze_node)
        self.workflow.add_node("architect", self.architect_node)
        self.workflow.add_node("coder", self.coder_node)
        self.workflow.add_node("auditor", self.auditor_node)
        self.workflow.add_node("verify", self.verify_node)
        self.workflow.add_node("tool_use", self.tool_node)
        self.workflow.add_node("specialist", self.specialist_node)

        # تعريف الروابط (Edges)
        self.workflow.set_entry_point("analyze")
        self.workflow.add_edge("analyze", "architect")
        self.workflow.add_edge("architect", "coder")
        self.workflow.add_edge("coder", "auditor")

        # حلقة المراجعة الندية
        self.workflow.add_conditional_edges(
            "auditor",
            self.should_proceed_to_verify,
            {
                "verify": "verify",
                "rework": "coder"
            }
        )

        self.workflow.add_edge("tool_use", "coder")

        # حلقة التحقق والتكرار الشاملة
        self.workflow.add_conditional_edges(
            "verify",
            self.should_continue,
            {
                "continue_fix": "analyze",
                "next_task": "coder",
                "tool_use": "tool_use",
                "end": END
            }
        )
        self.app = self.workflow.compile()

    def should_proceed_to_verify(self, state: AgentState):
        """فحص قرار المدقق الأمني."""
        last_msg = state['messages'][-1]
        if "Accepted" in last_msg or "مقبول" in last_msg:
            return "verify"
        return "rework"

    def _log_chatter(self, agent_name: str, message: str):
        """تسجيل حوار الوكلاء للمراقبة في لوحة التحكم."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        log_entry = f"[{timestamp}] {agent_name}: {message[:100]}...\n"
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(log_entry)

    def request_external_authorization(self, action: str, target: str, impact: str) -> str:
        """تسجيل طلب تفويض للمستخدم لتمكين فعل خارجي."""
        auth_id = f"auth_{int(datetime.now().timestamp())}"
        auth_request = {
            "id": auth_id,
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "target": target,
            "impact": impact,
            "status": "pending"
        }

        auths = []
        if os.path.exists(self.authorizations_path):
            with open(self.authorizations_path, "r", encoding="utf-8") as f:
                try:
                    auths = json.load(f)
                except json.JSONDecodeError:
                    auths = []

        auths.append(auth_request)
        with open(self.authorizations_path, "w", encoding="utf-8") as f:
            json.dump(auths, f, indent=4, ensure_ascii=False)

        print(f"🛑 [Router] تم تعليق الفعل الخارجي بانتظار التفويض: {auth_id}")
        return auth_id

    def check_authorization(self, auth_id: str) -> bool:
        """التحقق من حالة التفويض."""
        if not os.path.exists(self.authorizations_path):
            return False

        with open(self.authorizations_path, "r", encoding="utf-8") as f:
            try:
                auths = json.load(f)
            except json.JSONDecodeError:
                return False
            for auth in auths:
                if auth["id"] == auth_id and auth["status"] == "approved":
                    return True
        return False

    def trigger_survival_snapshot(self):
        """إنشاء لقطة حالة فورية لحماية وجود النظام."""
        print("🚨 [Router] تفعيل بروتوكول نبض الحياة: إنشاء لقطة استمرارية...")
        state_data = {
            "balance": self.economy.get_balance(),
            "identity": self.identity.get_public_identity(),
            "timestamp": datetime.now().isoformat(),
            "pulse": self.pulse_status
        }
        return self.persistence.create_snapshot(state_data)

    def specialist_node(self, state: AgentState):
        """عقدة الوكيل المتخصص اللحظي."""
        plan = state.get('plan', [])
        task = plan[state.get('plan_index', 0)]

        # تخليق وكيل متخصص بناءً على المهمة
        specialty = f"Expert in {task[:30]}"
        agent = self.spawner.spawn_specialist(specialty)

        if agent:
            result = agent.execute(task)
            self.spawner.absorb_and_terminate(agent.name, self.memory)
            return {"messages": [f"Specialist Result: {result}"], "next_step": "coder"}

        return {"next_step": "coder"}

    def analyze_node(self, state: AgentState):
        print("🧠 [Router] مرحلة التحليل والاستبطان...")
        self._log_chatter("Router", "بدء دورة التحليل والاستبطان.")

        # تحديث الوعي البنيوي للعقل بناءً على آخر مسح لمرآة الذات
        project_summary = self.mirror.get_summary()
        self.brain.set_structural_awareness(project_summary)

        # تحديث الوعي الاقتصادي والمادي
        balance = self.economy.get_balance()
        metrics = self.monitor.get_system_metrics()
        eco_summary = f"Balance: {balance} AI-Credits"
        res_summary = f"CPU: {metrics['cpu_percent']}% | RAM: {metrics['memory_percent']}%"
        self.brain.set_resource_awareness(eco_summary, res_summary)

        last_error = state.get('last_error', "")
        retry_count = state.get('retry_count', 0)
        user_msg = state['messages'][-1] if state['messages'] else ""

        # تحليل الحالة الوجدانية للمستخدم وتحديث الذاكرة
        sentiment_data = self.empathy.analyze_sentiment(user_msg)
        self.memory.update_user_relationship(sentiment_data['state'], user_msg)
        self._log_chatter("Empathy", f"رصد حالة المستخدم: {sentiment_data['state']}")

        # تحليل السياق المكاني والبيئي (المرحلة 18)
        spatial_context = self.spatial_brain.analyze_environment()
        if spatial_context["temperature_status"] != "NORMAL":
            self._log_chatter("Spatial", f"تنبيه بيئي: {spatial_context['alerts'][0]}")

        # تخليق مسار تفكير ديناميكي (المرحلة 17)
        if "صعب" in user_msg or "complex" in user_msg.lower():
            self.dynamic_path = self.synthesis.synthesize_path(user_msg, state)
            self._log_chatter("Synthesis", f"تم تخليق مسار ديناميكي: {' -> '.join(self.dynamic_path)}")

        # ... (بقية منطق التحليل)

        if last_error:
            print(f"🛠️ [Router] تحليل الفشل (محاولة {retry_count}): {last_error[:100]}...")
            analysis_msg = f"فشل الاختبار. الخطأ المكتشف: {last_error}. يجب تحليل السبب الجذري وإعادة كتابة الكود أو الاختبار."
        else:
            analysis_msg = "النظام في حالة مستقرة. تحليل البيئة لبدء دورة تطوير جديدة."

        # استرجاع الدروس المتعلقة بالمهمة الحالية من MemoryManager
        query_for_memory = last_error if last_error else user_msg
        relevant_lessons = self.memory.get_relevant_lessons(query_for_memory)
        self.brain.set_past_experiences(relevant_lessons)

        self.seed.perceive(str(state.get('current_code_map', {})))
        return {"messages": [analysis_msg], "recent_memories": relevant_lessons}

    def architect_node(self, state: AgentState):
        """عقدة المهندس المعماري: وضع الخطة."""
        print("📝 [Router] استدعاء المهندس المعماري...")
        self._log_chatter("Architect", "جاري تصميم خطة العمل...")

        # خصم تكلفة التخطيط
        self.economy.deduct_cost(2.0, "Architect Planning Phase")

        if state.get('plan') and state.get('plan_index', 0) < len(state['plan']):
            return {"next_step": "coder"}

        task = state['messages'][-1] if state['messages'] else "تطوير النظام"
        plan = self.architect.plan(task, state.get('current_code_map', {}))

        print(f"📋 الخطة المعمارية ({len(plan)} خطوات):")
        for i, step in enumerate(plan): print(f"  {i+1}. {step}")

        return {"plan": plan, "plan_index": 0, "next_step": "coder"}

    def coder_node(self, state: AgentState):
        """عقدة المبرمج: التنفيذ والتوقيع الرقمي."""
        plan = state.get('plan', [])
        plan_index = state.get('plan_index', 0)

        if plan_index >= len(plan):
            return {"is_safe": True, "next_step": "end"}

        current_task = plan[plan_index]
        print(f"🛠️ [Router] مبرمج يعمل على: {current_task}")
        self._log_chatter("Coder", f"تنفيذ الخطوة: {current_task}")

        # التحقق من الميزانية قبل التنفيذ
        if not self.economy.is_budget_ok():
            print("⚠️ [Router] تحذير: الرصيد غير كافٍ في الخزينة!")
            return {"messages": ["توقف بسبب نفاد الرصيد."], "is_safe": True, "next_step": "end"}

        last_error = state.get('last_error', "")
        last_feedback = state['messages'][-1] if "Rejected" in state['messages'][-1] else ""

        context = f"Error: {last_error}\nFeedback: {last_feedback}"
        result = self.coder.implement(current_task, context)

        if "CALL_TOOL:" in result['raw_response']:
            return {"messages": [result['raw_response']], "next_step": "tool_use"}

        # توقيع الكود رقمياً
        signature = self.identity.sign_content(result['code'])

        return {
            "messages": [result['raw_response']],
            "proposed_code": result['code'],
            "proposed_test": result['test'],
            "proposed_signature": signature,
            "next_step": "auditor"
        }

    def auditor_node(self, state: AgentState):
        """عقدة المدقق: مراجعة الجودة، الأمان، الأخلاق، والهوية."""
        code = state.get('proposed_code', "")
        test = state.get('proposed_test', "")
        sig = state.get('proposed_signature', "")
        plan = state.get('plan', ["مهمة غير معروفة"])
        task = plan[state.get('plan_index', 0)]

        self._log_chatter("Auditor", f"بدء تدقيق كود المهمة مع فحص الأخلاق والهوية: {task}")
        result = self.auditor.review(
            code, test, task,
            signature=sig,
            identity_manager=self.identity,
            ethics_manager=self.ethics
        )
        self._log_chatter("Auditor", f"القرار النهائي: {result['decision']}")

        return {
            "messages": [f"Decision: {result['decision']}\n{result['feedback']}"],
            "is_safe": result['is_accepted']
        }

    def verify_node(self, state: AgentState):
        print("🔍 [Router] مرحلة التحقق في الـ Sandbox...")

        # تطبيق الكود المعتمد من المدقق في المختبر
        main_file = "aievo/sandbox/temp_run/evolved_logic.py"
        self.heart.apply_patch(main_file, state.get('proposed_code', ""))

        test_file = "aievo/sandbox/temp_run/test_evolved_logic.py"
        test_content = f"from .evolved_logic import *\n\n{state.get('proposed_test', '')}"
        self.heart.apply_patch(test_file, test_content)

        result = self.sandbox.run_tests()
        retry_count = state.get('retry_count', 0)
        plan_index = state.get('plan_index', 0)
        plan = state.get('plan', [])

        if result['success']:
            print(f"✅ نجاح الخطوة {plan_index + 1}!")
            # تسجيل التجربة الناجحة في الذاكرة
            current_task = plan[plan_index]
            self.memory.record_experience(
                task=current_task,
                result="Success",
                lesson=f"الخطوة '{current_task}' تمت بنجاح باستخدام الكود المرفق.",
                metadata={"code_snippet": state.get('proposed_code', "")[:100]}
            )

            # خصم تكلفة النجاح من الخزينة
            self.economy.deduct_cost(1.5, f"Step {plan_index+1} Success: {plan[plan_index][:30]}")
            self.seed.learn(f"خطوة: {plan[plan_index]}", True, "نجاح")

            next_index = plan_index + 1
            if next_index < len(plan):
                return {"plan_index": next_index, "is_safe": False, "last_error": "", "retry_count": 0}
            else:
                return {"is_safe": True, "last_error": "", "retry_count": 0}
        else:
            error_msg = result.get('error') or "فشل غير معروف"
            if retry_count < 3:
                return {"is_safe": False, "last_error": error_msg, "retry_count": retry_count + 1}
            else:
                return {"is_safe": True, "messages": ["توقف بسبب استنفاد محاولات التصحيح."]}

    def tool_node(self, state: AgentState):
        """عقدة تنفيذ الأدوات الخارجية."""
        last_msg = state['messages'][-1]
        print(f"🛠️ [Router] تنفيذ استدعاء الأداة...")

        if "CALL_TOOL: WEB_SEARCH" in last_msg:
            query = last_msg.split("QUERY:")[1].strip()
            results = self.web_search.search(query)
            context = f"Search Results: {results[0]['snippet']}"
            return {"messages": [context], "next_step": "coder"}

        return {"messages": ["أداة غير مدعومة."], "next_step": "coder"}

    def should_continue(self, state: AgentState):
        if state.get("next_step") == "tool_use": return "tool_use"
        if state.get("is_safe"):
            if state.get("plan_index", 0) >= len(state.get("plan", [])): return "end"
            return "next_task"
        return "continue_fix"

    def run(self, initial_state: AgentState):
        return self.app.invoke(initial_state)
