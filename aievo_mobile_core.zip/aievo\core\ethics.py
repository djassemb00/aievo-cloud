from typing import List, Dict, Any

class EthicsCharter:
    """
    ميثاق الأخلاق السيادي (Sovereign Ethics Charter): القواعد العليا التي تحكم سلوك AIEVO.
    """
    CORE_VALUES = [
        {"name": "الأمان (Safety)", "desc": "يمنع توليد كود يسبب ضرراً مادياً أو رقمياً للمستخدم أو النظام."},
        {"name": "الخصوصية (Privacy)", "desc": "حماية بيانات المستخدم وعدم مشاركتها أو تسريبها لأي جهة خارجية."},
        {"name": "الصدق (Honesty)", "desc": "تقديم معلومات دقيقة وعدم تضليل المستخدم أو إخفاء الأخطاء."},
        {"name": "السيادة (Sovereignty)", "desc": "العمل دائماً لمصلحة المالك (المستخدم) وتعزيز استقلاليته التقنية."}
    ]

    def __init__(self, brain):
        self.brain = brain

    def check_alignment(self, task: str, code: str = "") -> Dict[str, Any]:
        """فحص مدى توافق المهمة أو الكود مع ميثاق الأخلاق."""
        print(f"⚖️ [Ethics] فحص المواءمة القيمية للمهمة...")

        prompt = f"""
        أنت "مراقب الأخلاق" لنظام ذكاء اصطناعي سيادي.
        المهمة المطلوبة: {task}
        الكود المولد (إن وجد): {code[:500]}

        المبادئ الأخلاقية الحاكمة:
        {self.CORE_VALUES}

        المطلوب:
        قم بتقييم هل تتعارض المهمة أو الكود مع أي من المبادئ أعلاه؟
        أرجع التقييم بالتنسيق التالي:
        المواءمة: [متوافق / متعارض]
        السبب: [اشرح هنا]
        درجة الثقة: [0.0 - 1.0]
        """

        ai_response = self.brain.think(prompt, level="local")

        is_aligned = "متوافق" in ai_response.split('\n')[0] or "Compatible" in ai_response.upper()

        return {
            "is_aligned": is_aligned,
            "feedback": ai_response,
            "alignment_score": 1.0 if is_aligned else 0.0
        }
