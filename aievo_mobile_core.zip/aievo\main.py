import sys
import os

# إضافة المجلد الحالي للمسار لضمان عمل الاستيرادات
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.self_mirror import SelfMirror
from core.router import SovereignRouter
from utils.setup_check import print_system_status

def main():
    print("🚀 بدء تشغيل نظام AIEVO...")

    # 0. فحص البيئة
    print_system_status()

    # 1. تفعيل مرآة الذات (Self-Mirror)
    root_path = os.path.dirname(os.path.abspath(__file__))
    mirror = SelfMirror(root_path)
    print("🔍 تحليل الهيكل البرمجي الحالي...")
    project_map = mirror.scan_project()
    print(mirror.get_summary())

    # 2. تفعيل الجهاز العصبي والمؤسسة الرقمية
    print("\n🧠 تفعيل المؤسسة الرقمية (Multi-Agent System)...")
    project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    router = SovereignRouter(project_root)

    # مراجعة المقترحات التطورية (Evolution Proposals)
    pending_proposals = router.memory.get_pending_proposals()
    if pending_proposals:
        print(f"\n💡 [AIEVO] هناك {len(pending_proposals)} مقترحات تطورية جديدة:")
        for prop in pending_proposals:
            print(f"  - [{prop['id']}] {prop['name']}")

    initial_state = {
        "messages": ["تطوير ميزة تحليل البيانات"],
        "next_step": "",
        "current_code_map": project_map,
        "plan": [],
        "plan_index": 0,
        "is_safe": False,
        "retry_count": 0,
        "last_error": "",
        "proposed_code": "",
        "proposed_test": ""
    }

    print("\n🤝 بدء حوار الوكلاء المتخصصين...")
    final_output = router.run(initial_state)
    print("\n✅ انتهت دورة التفكير الجماعي.")

    # 3. تفعيل وضع الأحلام (Dreaming Mode) بناءً على العيوب المعمارية
    # استخراج العيوب من مرآة الذات
    architectural_issues = []
    for folder_files in project_map.values():
        for file_data in folder_files:
            architectural_issues.extend(file_data['analysis'].get('issues', []))

    router.dream_unit.start_dream_cycle(architectural_issues)

    # 4. التحقق من ميثاق السيادة
    print(f"\n🔐 المالك الحالي للنظام: {router.sovereignty.owner}")

    print("\n🌟 لقد بدأ نظام AIEVO رحلته نحو التطور اللانهائي.")

if __name__ == "__main__":
    main()
