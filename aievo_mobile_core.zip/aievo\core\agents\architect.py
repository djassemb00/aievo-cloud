from typing import List, Dict, Any

class ArchitectAgent:
    """
    وكيل الهندسة المعمارية (Architect Agent):
    المسؤول عن التخطيط وتصميم هيكلية الحل قبل البدء في البرمجة.
    """
    def __init__(self, brain):
        self.brain = brain

    def plan(self, task_description: str, code_map: Dict[str, Any]) -> List[str]:
        print("🏛️ [Architect] جاري تحليل المهمة وتصميم خطة العمل...")

        prompt = f"""
        أنت مهندس برمجيات محترف (Software Architect).
        المهمة المطلوبة: {task_description}
        حالة المشروع الحالية: {code_map}

        المطلوب:
        ضع خطة عمل (To-Do List) دقيقة ومنظمة لتنفيذ هذه المهمة.
        قسم الخطة إلى خطوات بسيطة، كل خطوة تركز على جزء محدد.
        اكتب الخطة كقائمة مرقمة فقط.
        """

        ai_response = self.brain.think(prompt, level="cloud")

        # استخراج الخطوات من الرد
        plan = []
        for line in ai_response.split('\n'):
            line = line.strip()
            if line and (line[0].isdigit() or line.startswith('-')):
                plan.append(line)

        if not plan:
            plan = [f"تنفيذ المهمة: {task_description}"]

        return plan
