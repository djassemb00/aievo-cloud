import os

class Deployer:
    """
    محرك الانتشار (Deployment Engine): مسؤول عن حزم ونشر تطبيقات AIEVO.
    """
    def __init__(self, project_root: str):
        self.project_root = project_root

    def generate_dockerfile(self, service_name: str, entry_point: str) -> str:
        """توليد ملف Dockerfile للخدمة."""
        docker_content = f"""
FROM python:3.10-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["python", "{entry_point}"]
"""
        dockerfile_path = os.path.join(self.project_root, f"Dockerfile.{service_name}")
        with open(dockerfile_path, "w", encoding="utf-8") as f:
            f.write(docker_content.strip())

        print(f"🐳 [Deployer] تم إنشاء Dockerfile للخدمة: {service_name}")
        return dockerfile_path

    def generate_cloud_stack(self) -> str:
        """توليد ملفات التكوين السحابي (Docker Compose) لبيئة سيادية كاملة."""
        compose_content = """
services:
  aievo-core:
    build: .
    ports:
      - "8000:8000"
    environment:
      - SOVEREIGN_MODE=true
  aievo-dashboard:
    build: .
    command: streamlit run aievo/web/dashboard.py
    ports:
      - "8501:8501"
  chroma-db:
    image: chromadb/proto:latest
    ports:
      - "8001:8001"
"""
        compose_path = os.path.join(self.project_root, "docker-compose.yml")
        with open(compose_path, "w", encoding="utf-8") as f:
            f.write(compose_content.strip())

        print(f"☁️ [Deployer] تم توليد ملف التكوين السحابي: docker-compose.yml")
        return compose_path
