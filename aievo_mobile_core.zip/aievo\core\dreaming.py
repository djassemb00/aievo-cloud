import time
import random
from typing import List
from .brain import Brain
from .heart import Heart
from .immune_system import ImmuneSystem
from sandbox.manager import SandboxManager
from memory.manager import MemoryManager

class DreamingModule:
    """
    وحدة الأحلام الرقمية (Dreaming Module): المسؤولة عن التطوير الاستباقي
    في أوقات خمول النظام عبر محاكاة سيناريوهات تطويرية.
    """
    def __init__(self, brain: Brain, heart: Heart, immune_system: ImmuneSystem, sandbox: SandboxManager, memory: MemoryManager):
        self.brain = brain
        self.heart = heart
        self.immune_system = immune_system
        self.sandbox = sandbox
        self.memory = memory
        self.is_dreaming = False

    def start_dream_cycle(self, architectural_issues: List[str] = None):
        """
        بدء دورة الحلم البرمجي.
        إذا توفرت عيوب معمارية، يحاول الحلم حل أحدها.
        """
        print("\n🌙 [AIEVO] الدخول في وضع الأحلام الرقمية...")
        self.is_dreaming = True

        if architectural_issues:
            print(f"🧐 [Dream] رصد {len(architectural_issues)} عيوب معمارية. محاولة حل أحدها...")
            chosen_issue = random.choice(architectural_issues)
            prompt = f"""
            أنت في وضع الحلم التطوري. لقد رصد نظام 'مرآة الذات' العيب المعماري التالي:
            {chosen_issue}

            تخيل حلاً برمجياً مبتكراً ونظيفاً لهذا العيب.
            اكتب الكود المصحح داخل ```python.
            """
            chosen_scenario = f"حل العيب المعماري: {chosen_issue[:50]}..."
        else:
            # محاكاة سيناريو "تخيلي" عام إذا لم توجد عيوب
            scenarios = [
                "تحسين دالة التشفير الحالية",
                "إضافة ميزة البحث الذكي في الذاكرة",
                "تقليل استهلاك الذاكرة العشوائية",
                "بناء موديول بلغة Rust لزيادة السرعة"
            ]
            chosen_scenario = random.choice(scenarios)
            prompt = f"أنت في وضع الحلم. تخيل كيف ستنفذ المهمة التالية بأفضل طريقة ممكنة: {chosen_scenario}. اكتب الكود داخل ```python."

        print(f"💭 حلم اليوم: {chosen_scenario}")

        # 1. التخيل (توليد الكود في العقل)
        dream_code_raw = self.brain.think(prompt)

        if "```python" in dream_code_raw:
            dream_code = dream_code_raw.split("```python")[1].split("```")[0].strip()
        else:
            dream_code = dream_code_raw

        # 2. التجربة في "الخيال" (الـ Sandbox)
        print("🧪 تجربة الحلم في المختبر المعزول...")
        if self.immune_system.scan_code(dream_code):
            self.sandbox.prepare_sandbox()

            # محاكاة نجاح التجربة (في المستقبل سنشغل pytest حقيقي هنا أيضاً)
            print("✨ تجربة الحلم نجحت في المختبر الافتراضي.")

            # تسجيل الاقتراح التطوري
            self.memory.record_proposal(
                name=chosen_scenario,
                code=dream_code,
                description=f"تحسين آلي ناتج عن وضع الأحلام لحل: {chosen_scenario}"
            )

            self.memory.record_experience(
                task=f"حلم: {chosen_scenario}",
                result="نجاح",
                lesson=f"تم اكتشاف حل فعال لـ {chosen_scenario}. تم رفع اقتراح تطوري."
            )
        else:
            print("🚫 كابوس برمجى: نظام المناعة رفض تجربة الحلم.")

        self.is_dreaming = False
