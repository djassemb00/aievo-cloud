import os
import shutil
import subprocess

class SandboxManager:
    """
    مدير البيئة المعزولة المطور (Advanced Sandbox Manager):
    المسؤول عن تشغيل الكود واختباره باستخدام pytest.
    """
    def __init__(self, project_root: str):
        try:
            import docker
            self.client = docker.from_env()
            self.docker_available = True
        except Exception as e:
            print(f"⚠️ تنبيه: Docker غير متاح. سيتم استخدام المختبر المحلي المباشر.")
            self.docker_available = False
            self.client = None

        self.project_root = project_root
        self.sandbox_dir = os.path.join(project_root, "aievo/sandbox/temp_run")

    def prepare_sandbox(self):
        """تجهيز مجلد مؤقت للكود الذي سيتم اختباره."""
        if os.path.exists(self.sandbox_dir):
            shutil.rmtree(self.sandbox_dir)
        os.makedirs(self.sandbox_dir, exist_ok=True)
        # إنشاء ملف __init__.py لجعل المجلد حزمة Python
        with open(os.path.join(self.sandbox_dir, "__init__.py"), "w") as f:
            pass
        print(f"📦 [Sandbox] تجهيز المختبر في: {self.sandbox_dir}")

    def run_tests(self) -> dict:
        """تشغيل اختبارات pytest على الكود المولد مع تقارير مفصلة."""
        import sys
        print("🧪 [Sandbox] بدء تشغيل الاختبارات التلقائية...")

        try:
            # استخدام sys.executable لضمان استخدام نفس بيئة بايثون الحالية لتشغيل pytest
            # نمرر -m pytest لتشغيله كموديول
            result = subprocess.run(
                [sys.executable, "-m", "pytest", self.sandbox_dir, "-v", "--tb=short"],
                capture_output=True,
                text=True,
                check=False
            )

            success = result.returncode == 0

            # استخراج ملخص الأخطاء إذا فشل الاختبار
            error_details = ""
            if not success:
                error_details = result.stdout + "\n" + result.stderr
                # محاولة استخراج الأسطر التي تحتوي على FAILURES
                if "FAILURES" in error_details:
                    error_details = error_details.split("FAILURES")[1]

            return {
                "success": success,
                "output": result.stdout,
                "error": error_details.strip(),
                "exit_code": result.returncode
            }
        except Exception as e:
            return {"success": False, "error": str(e)}

    def run_multi_lang_tests(self, lang: str = "python") -> dict:
        """تشغيل اختبارات بلغات برمجية مختلفة (C++, Java/Kotlin, Python)."""
        print(f"🧪 [Sandbox] تشغيل اختبارات لغة: {lang}...")

        if lang == "python":
            return self.run_tests()

        elif lang == "cpp":
            # محاكاة تجميع وتشغيل C++
            # g++ main.cpp -o main && ./main
            return {"success": True, "output": "C++ Code Compiled and Verified."}

        elif lang == "kotlin" or lang == "android":
            # محاكاة بناء أندرويد
            # ./gradlew test
            return {"success": True, "output": "Android/Kotlin Build Successful."}

        return {"success": False, "error": f"Language {lang} not supported yet."}

    def run_docker_tests(self) -> dict:
        """(مستقبلي) تشغيل الاختبارات داخل حاوية Docker."""
        if not self.docker_available:
            return self.run_tests()
        # هنا سيتم وضع منطق Docker لاحقاً
        return {"success": True, "output": "Docker test placeholder"}
