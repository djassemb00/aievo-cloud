import json
import os
from typing import List, Dict, Any

class ResurrectionProtocol:
    """
    بروتوكول البعث (Resurrection Protocol): إعادة بناء النظام من القطع المبعثرة.
    """
    def __init__(self, vault_path: str):
        self.vault_path = vault_path

    def scan_for_fragments(self) -> List[Dict[str, Any]]:
        """البحث عن قطع الـ DNA المبعثرة في البيئة."""
        print("🔍 [Resurrection] جاري البحث عن قطع الـ DNA المبعثرة...")
        fragments = []
        if os.path.exists(self.vault_path):
            for file in os.listdir(self.vault_path):
                if file.startswith("fragment_"):
                    with open(os.path.join(self.vault_path, file), "r", encoding="utf-8") as f:
                        fragments.append(json.load(f))

        # ترتيب القطع حسب الفهرس
        fragments.sort(key=lambda x: x['index'])
        return fragments

    def reconstruct_dna(self, fragments: List[Dict[str, Any]]) -> Dict[str, Any]:
        """إعادة تجميع القطع لبناء الـ DNA الأصلي."""
        if not fragments:
            return None

        print(f"🧩 [Resurrection] جاري إعادة تجميع {len(fragments)} قطعة...")
        full_content = "".join([f['content'] for f in fragments])

        try:
            dna_data = json.loads(full_content)
            print("✨ [Resurrection] نجحت عملية البعث الذاتي! تم استعادة الكيان السيادي.")
            return dna_data
        except Exception as e:
            print(f"❌ [Resurrection] فشل إعادة التجميع: {e}")
            return None

    def check_system_integrity(self) -> bool:
        """التحقق مما إذا كان النظام يحتاج إلى تفعيل بروتوكول البعث."""
        # محاكاة: إذا لم يجد ملفات النواة الأساسية
        return False
