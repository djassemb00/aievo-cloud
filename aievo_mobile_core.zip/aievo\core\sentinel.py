import os
from cryptography.fernet import Fernet
import base64
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

class Sentinel:
    """
    الحارس (Sentinel): مسؤول عن التشفير السيادي والأمن.
    """
    def __init__(self, owner_secret: str = "AIEVO_SOVEREIGN_KEY"):
        self.key = self._generate_key(owner_secret)
        self.cipher = Fernet(self.key)

    def _generate_key(self, secret: str) -> bytes:
        """توليد مفتاح تشفير من كلمة سر المالك."""
        salt = b'aievo_salt_123' # في الإنتاج يجب أن يكون عشوائياً ومخزناً بأمان
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
        )
        key = base64.urlsafe_b64encode(kdf.derive(secret.encode()))
        return key

    def encrypt_data(self, data: str) -> bytes:
        """تشفير البيانات (AES-256)."""
        return self.cipher.encrypt(data.encode())

    def decrypt_data(self, encrypted_data: bytes) -> str:
        """فك تشفير البيانات."""
        return self.cipher.decrypt(encrypted_data).decode()

    def secure_backup(self, file_path: str):
        """إنشاء نسخة احتياطية مشفرة من ملف."""
        if not os.path.exists(file_path): return False

        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        encrypted_content = self.encrypt_data(content)
        backup_path = file_path + ".aes"

        with open(backup_path, "wb") as f:
            f.write(encrypted_content)

        print(f"🔐 [Sentinel] تم إنشاء نسخة احتياطية مشفرة: {os.path.basename(backup_path)}")
        return True

    def monitor_api_access(self, request_info: dict) -> bool:
        """مراقبة الوصول للـ API (محاكاة)."""
        print(f"🛡️ [Sentinel] مراقبة طلب وصول من: {request_info.get('ip', 'unknown')}")
        # منطق بسيط للتحقق من التهديدات
        return True
