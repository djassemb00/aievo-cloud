import os
from typing import List, Dict, Any

class GeneticLab:
    """
    مختبر الطفرات الجينية (Genetic Lab): مسؤول عن التطوير المعماري الذاتي للنظام.
    """
    def __init__(self, brain, mirror, heart, sandbox):
        self.brain = brain
        self.mirror = mirror
        self.heart = heart
        self.sandbox = sandbox

    def analyze_self_architecture(self) -> List[Dict[str, Any]]:
        """تحليل هيكلية النظام الخاصة بـ AIEVO لاكتشاف نقاط الضعف."""
        print("🔬 [GeneticLab] بدء تحليل الهيكل الجوهري للنظام...")
        project_map = self.mirror.scan_project()

        # استخراج العيوب المعمارية من الملفات الأساسية فقط
        core_issues = []
        for folder, files in project_map.items():
            if "core" in folder:
                for file_data in files:
                    issues = file_data['analysis'].get('issues', [])
                    if issues:
                        core_issues.append({
                            "file": file_data['filename'],
                            "issues": issues
                        })
        return core_issues

    def propose_mutation(self, file_path: str, issues: List[str]) -> str:
        """توليد طفرة (نسخة محسنة) من ملف أساسي."""
        print(f"🧬 [GeneticLab] توليد طفرة جينية للملف: {file_path}")

        with open(file_path, "r", encoding="utf-8") as f:
            current_code = f.read()

        prompt = f"""
        أنت مهندس أنظمة خبير. المطلوب هو إجراء "طفرة جينية" (تحسين معماري) للملف التالي:
        المسار: {file_path}
        العيوب المعمارية المكتشفة: {issues}
        الكود الحالي:
        ```python
        {current_code}
        ```

        المطلوب:
        أعد كتابة الملف لتحسين جودته، تقليل تعقيده، ومعالجة العيوب المذكورة.
        يجب أن تظل الوظيفة الأساسية للملف كما هي تماماً.
        أرجع الكود الجديد بالكامل داخل علامات ```python.
        """

        mutation_code = self.brain.think(prompt, level="cloud")
        if "```python" in mutation_code:
            return mutation_code.split("```python")[1].split("```")[0].strip()
        return ""

    def test_mutation(self, file_path: str, mutation_code: str) -> bool:
        """اختبار الطفرة في الـ Sandbox قبل التطبيق."""
        print(f"🧪 [GeneticLab] اختبار الطفرة الجينية للملف {os.path.basename(file_path)}...")
        self.sandbox.prepare_sandbox()

        # تطبيق الطفرة في مجلد مؤقت
        temp_file = os.path.join(self.sandbox.sandbox_path, "temp_run", "mutation_test.py")
        self.heart.apply_patch(temp_file, mutation_code)

        # تشغيل اختبارات الوحدة (بشكل مبسط حالياً)
        result = self.sandbox.run_tests()
        return result['success']
