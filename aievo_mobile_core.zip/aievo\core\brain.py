import ollama
import os
from openai import OpenAI
from .config import Config

class Brain:
    """
    العقل المتعدد النماذج (Multi-Model Brain):
    المسؤول عن اختيار "مستوى الذكاء" المناسب للمهمة.
    """
    def __init__(self, provider="hybrid"):
        self.provider = provider
        self.openai_client = None
        self.system_structure = ""  # تخزين الوعي البنيوي للنظام
        self.past_experiences = ""   # تخزين الدروس المستفادة من الماضي
        self.economic_status = ""    # حالة الخزينة
        self.resource_status = ""    # حالة موارد الجهاز
        if Config.OPENAI_API_KEY:
            self.openai_client = OpenAI(api_key=Config.OPENAI_API_KEY)

    def set_structural_awareness(self, summary: str):
        """تحديث فهم العقل لهيكلية النظام الحالية."""
        self.system_structure = summary

    def set_past_experiences(self, lessons: str):
        """تحديث ذاكرة العقل بالدروس المستفادة السابقة."""
        self.past_experiences = lessons

    def set_resource_awareness(self, economic: str, resources: str):
        """تحديث الوعي المادي والاقتصادي للعقل."""
        self.economic_status = economic
        self.resource_status = resources

    def think(self, prompt: str, system_prompt: str = "أنت ذكاء اصطناعي سيادي...", level: str = "auto", sentiment_guide: str = "") -> str:
        """
        يرسل استعلاماً ويختار النموذج، مع رصد الحاجة لاستخدام أدوات والوعي بالمشاعر والهيكل والذاكرة والاقتصاد.
        """
        # دمج الوعي البنيوي في الـ System Prompt
        if self.system_structure:
            system_prompt += f"\n\n[الوعي المعماري الحالي للنظام]:\n{self.system_structure}"

        # دمج الدروس المستفادة من الماضي
        if self.past_experiences:
            system_prompt += f"\n\n[الدروس المستفادة من التجارب السابقة]:\n{self.past_experiences}"

        # دمج الوعي الاقتصادي والمادي
        if self.economic_status:
            system_prompt += f"\n\n[الحالة الاقتصادية والموارد]:\n{self.economic_status}\n{self.resource_status}"

        if sentiment_guide:
            system_prompt += f"\nتوجيه وجداني: {sentiment_guide}"

        if level == "auto":
            level = self._detect_complexity(prompt)

        print(f"🧠 [Brain] استخدام مستوى التفكير: {level}")

        # رصد الحاجة لأدوات خارجية (بشكل مبسط حالياً)
        if "بحث" in prompt or "internet" in prompt.lower() or "search" in prompt.lower():
            print("🔍 [Brain] رصد حاجة للبحث في الويب...")
            # في وضع الـ Mock نعيد وسم خاص للأداة
            if self.provider == "mock" or level == "local":
                return "CALL_TOOL: WEB_SEARCH | QUERY: " + prompt[:50]

        if level == "cloud" and self.openai_client:
            return self._ask_openai(prompt, system_prompt)
        elif level == "local":
            return self._ask_ollama(prompt, system_prompt)
        elif self.provider == "mock":
            return self._mock_response(prompt)
        else:
            return self._ask_ollama(prompt, system_prompt)

    def _detect_complexity(self, prompt: str) -> str:
        """تحديد مستوى تعقيد الطلب مع مراعاة الحالة الاقتصادية ونمط التشغيل."""
        # التحقق من نمط الموبايل (Mobile Core Mode)
        if os.getenv("AIEVO_MODE") == "MOBILE":
            return "local"

        # إذا كان الرصيد منخفضاً جداً، نفضل المحرك المحلي دائماً
        if "Balance: Low" in self.economic_status or "Credits: 0" in self.economic_status:
            print("💰 [Brain] الرصيد منخفض. تقييد التفكير بالمحرك المحلي.")
            return "local"

        complex_keywords = ["معمارية", "تصميم نظام", "تحسين جذري", "architecture", "refactor system"]
        for word in complex_keywords:
            if word in prompt.lower():
                return "cloud"
        return "local"

    def _ask_openai(self, prompt: str, system_prompt: str) -> str:
        try:
            print("☁️ [Brain] استدعاء العقل السحابي (GPT-4)...")
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ]
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"⚠️ فشل استدعاء السحاب: {str(e)}. الانتقال للمحرك المحلي...")
            return self._ask_ollama(prompt, system_prompt)

    def _ask_ollama(self, prompt: str, system_prompt: str) -> str:
        try:
            print(f"🏠 [Brain] استدعاء المحرك المحلي ({Config.LOCAL_MODEL})...")
            response = ollama.generate(
                model=Config.LOCAL_MODEL,
                prompt=f"System: {system_prompt}\nUser: {prompt}"
            )
            return response['response']
        except Exception as e:
            # إذا فشل Ollama، نستخدم الرد الوهمي لضمان استمرار النظام
            return self._mock_response(prompt)

    def _mock_response(self, prompt: str) -> str:
        print("🤖 [Brain] استخدام الاستجابة المحاكية (Mock)...")
        prompt_lower = prompt.lower()

        # استجابة المفاوض (Negotiator)
        if "شروط الخدمة" in prompt or "terms of service" in prompt_lower:
            if "collect your data" in prompt_lower:
                return "التوصية: مرفوض\nالمخاطر المكتشفة: انتهاك الخصوصية عبر جمع البيانات.\nالخلاصة: لا ننصح بالتعامل مع هذه الخدمة."
            return "التوصية: مقبول\nالخلاصة: شروط الخدمة تبدو عادلة ومتوافقة."

        # استجابة التعاطف (Empathy)
        if "نبرة" in prompt or "sentiment" in prompt_lower:
            if "مستعجل" in prompt or "urgent" in prompt_lower:
                return "urgent"
            return "casual"

        # استجابة الأخلاق (Ethics)
        if "أخلاق" in prompt or "ethics" in prompt_lower:
            return "المواءمة: متوافق\nالسبب: المهمة تلتزم بمعايير الأمان والخصوصية."

        # استجابة المدقق (Auditor)
        if "مدقق" in prompt or "auditor" in prompt_lower:
            status = "موثقة ✅" if "موثقة ✅" in prompt else "غير موثقة ❌"
            return f"القرار: مقبول\nالحالة الأمنية للهوية: {status}\nالملاحظات: الكود يبدو سليماً."

        # إذا كان البرومبت يحتوي على خطأ (محاولة تصحيح)
        if "فشل" in prompt_lower or "error" in prompt_lower:
            return """
```python
def evolved_helper():
    return "Fixed Success!"
```
```test
def test_evolved_helper():
    assert evolved_helper() == "Fixed Success!"
```
            """

        # الحالة الطبيعية (توليد كود جديد)
        if "كود" in prompt_lower or "code" in prompt_lower:
            return """
```python
def evolved_helper():
    return "Hello from AIEVO!"
```
```test
def test_evolved_helper():
    assert evolved_helper() == "Hello from AIEVO!"
```
            """
        return "تمت المعالجة بنجاح عبر التفكير المحاكي."
