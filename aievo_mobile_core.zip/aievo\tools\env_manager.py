import subprocess
import sys
import os

class EnvManager:
    """
    مدير البيئة البرمجية: مسؤول عن إدارة المكتبات والتبعيات.
    """
    def __init__(self, project_root: str):
        self.project_root = project_root
        self.requirements_path = os.path.join(project_root, "requirements.txt")

    def install_package(self, package_name: str) -> bool:
        """تثبيت مكتبة بايثون جديدة."""
        print(f"📦 [EnvManager] محاولة تثبيت المكتبة: {package_name}...")
        try:
            # استخدام نفس مفسر بايثون الحالي
            subprocess.check_call([sys.executable, "-m", "pip", "install", package_name])
            print(f"✅ تم تثبيت {package_name} بنجاح.")
            self._update_requirements(package_name)
            return True
        except Exception as e:
            print(f"❌ فشل تثبيت المكتبة: {e}")
            return False

    def check_package(self, package_name: str) -> bool:
        """التحقق من وجود مكتبة."""
        import importlib.util
        return importlib.util.find_spec(package_name) is not None

    def _update_requirements(self, package_name: str):
        """تحديث ملف requirements.txt."""
        if os.path.exists(self.requirements_path):
            with open(self.requirements_path, "r", encoding="utf-8") as f:
                content = f.read()

            if package_name not in content:
                with open(self.requirements_path, "a", encoding="utf-8") as f:
                    f.write(f"\n{package_name}")
                print(f"📝 تم تحديث requirements.txt بإضافة {package_name}")
