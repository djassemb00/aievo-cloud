import json
import os
import requests
from typing import List, Dict, Any
from datetime import datetime

class SwarmSync:
    """
    محرك السرب (Swarm Sync): مسؤول عن مزامنة الذاكرة والدروس بين نسخ AIEVO المختلفة.
    """
    def __init__(self, node_id: str, peer_urls: List[str] = None):
        self.node_id = node_id
        self.peer_urls = peer_urls or []
        self.sync_log = []

    def broadcast_lesson(self, lesson: Dict[str, Any]):
        """بث درس مستفاد جديد إلى جميع العقد في السرب."""
        return self._broadcast("LESSON", lesson)

    def broadcast_proposal(self, proposal: Dict[str, Any]):
        """بث مقترح جديد للتصويت عليه."""
        return self._broadcast("PROPOSAL", proposal)

    def broadcast_vote(self, proposal_id: str, vote: bool):
        """بث صوت العقدة على مقترح معين."""
        data = {"proposal_id": proposal_id, "voter_id": self.node_id, "vote": vote}
        return self._broadcast("VOTE", data)

    def broadcast_wisdom(self, wisdom: str):
        """بث حكمة مقطرة جديدة للسرب بالكامل."""
        return self._broadcast("DISTILLED_WISDOM", {"wisdom": wisdom})

    def _broadcast(self, msg_type: str, data: Dict[str, Any]):
        print(f"📡 [SwarmSync] بث رسالة من نوع {msg_type} من العقدة {self.node_id}...")
        payload = {
            "type": msg_type,
            "source_node": self.node_id,
            "timestamp": datetime.now().isoformat(),
            "data": data
        }

        success_count = 0
        for url in self.peer_urls:
            # محاكاة البث
            success_count += 1

        print(f"✅ تمت المزامنة مع {success_count} عقدة.")
        return success_count

    def receive_sync(self, payload: Dict[str, Any], router: Any):
        """استقبال بيانات المزامنة وتوجيهها للمكون المناسب."""
        msg_type = payload.get("type", "LESSON")
        source = payload.get("source_node")
        data = payload.get("data")

        print(f"📥 [SwarmSync] استلام رسالة {msg_type} من {source}...")

        if msg_type == "LESSON":
            router.memory.save_lesson(
                task=data.get("task", "مهمة شبكية"),
                success=data.get("success", True),
                lesson=f"مستقى من السرب ({source}): {data.get('lesson')}"
            )
        elif msg_type == "PROPOSAL":
            router.consensus.active_proposals[data['id']] = data
        elif msg_type == "VOTE":
            router.consensus.cast_vote(data['proposal_id'], data['voter_id'], data['vote'])
        elif msg_type == "DISTILLED_WISDOM":
            router.memory.record_experience("Collective Wisdom", "Unified", data['wisdom'])

        return True
