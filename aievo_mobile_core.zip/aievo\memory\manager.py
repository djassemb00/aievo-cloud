import os
import datetime
import json
import chromadb
from chromadb.utils import embedding_functions
from typing import List, Dict, Any

class MemoryManager:
    """
    مدير الذاكرة الدلالية (Semantic Memory Manager):
    يستخدم ChromaDB لتخزين واسترجاع الخبرات بناءً على التشابه المتجهي.
    """
    def __init__(self, project_root: str):
        self.project_root = project_root
        self.memory_dir = os.path.join(project_root, "aievo/memory/storage")
        os.makedirs(self.memory_dir, exist_ok=True)

        self.lessons_path = os.path.join(self.memory_dir, "lessons.jsonl")
        self.proposals_path = os.path.join(self.memory_dir, "proposals.jsonl")
        self.vector_db_path = os.path.join(self.memory_dir, "vector_db")
        self.proposals_dir = os.path.join(self.memory_dir, "proposals")
        os.makedirs(self.proposals_dir, exist_ok=True)

        self.relationship_path = os.path.join(self.memory_dir, "user_relationship.json")

        # إعداد ChromaDB
        try:
            self.chroma_client = chromadb.PersistentClient(path=self.vector_db_path)
            # استخدام نموذج تضمين محلي (سيبحث عن onnxruntime أو سيستخدم نموذجاً افتراضياً)
            self.emb_fn = embedding_functions.DefaultEmbeddingFunction()
            self.collection = self.chroma_client.get_or_create_collection(
                name="aievo_experiences",
                embedding_function=self.emb_fn
            )
            self.use_vector_db = True
            print("💎 [Memory] تفعيل الذاكرة المتجهية (ChromaDB) بنجاح.")
        except Exception as e:
            print(f"⚠️ [Memory] فشل تفعيل الذاكرة المتجهية: {e}. سيتم استخدام البحث النصي.")
            self.use_vector_db = False

        self._migrate_old_memory()

    def _migrate_old_memory(self):
        """ترحيل الذاكرة القديمة إلى ChromaDB إذا كانت متاحة."""
        if not self.use_vector_db: return

        # فحص إذا كانت المجموعة فارغة لنقوم بالترحيل من الملف
        if self.collection.count() == 0 and os.path.exists(self.lessons_path):
            print("📦 [Memory] ترحيل الخبرات من JSONL إلى الذاكرة المتجهية...")
            with open(self.lessons_path, "r", encoding="utf-8") as f:
                for i, line in enumerate(f):
                    data = json.loads(line)
                    self._add_to_vector_db(data, f"migrated_{i}")

    def record_experience(self, task: str, result: str, lesson: str, metadata: dict = None):
        """تسجيل تجربة جديدة في كل من JSONL والذاكرة المتجهية."""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = {
            "timestamp": timestamp,
            "task": task,
            "result": result,
            "lesson": lesson,
            "metadata": metadata or {}
        }

        # 1. حفظ في الملف (سجل مراجعة)
        with open(self.lessons_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

        # 2. حفظ في الذاكرة المتجهية
        if self.use_vector_db:
            exp_id = f"exp_{datetime.datetime.now().timestamp()}"
            self._add_to_vector_db(entry, exp_id)

        print(f"🧠 [Memory] تم حفظ درس جديد دلالياً: {lesson[:50]}...")

    def _add_to_vector_db(self, entry: dict, exp_id: str):
        """إضافة مستند إلى ChromaDB."""
        # النص الذي سيتم استخدامه للبحث (المهمة + الدرس)
        content = f"Task: {entry['task']}\nLesson: {entry['lesson']}"
        self.collection.add(
            documents=[content],
            metadatas=[entry],
            ids=[exp_id]
        )

    def get_relevant_lessons(self, query: str, limit: int = 3) -> str:
        """البحث الدلالي عن دروس مشابهة للطلب الحالي."""
        if self.use_vector_db:
            try:
                results = self.collection.query(
                    query_texts=[query],
                    n_results=limit
                )
                if results['documents'] and results['documents'][0]:
                    # استخراج الدروس من الميتاداتا
                    lessons = [m['lesson'] for m in results['metadatas'][0]]
                    return "\n---\n".join(lessons)
            except Exception as e:
                print(f"⚠️ [Memory] خطأ في البحث الدلالي: {e}")

        # البحث النصي التقليدي كخيار بديل
        return self._fallback_keyword_search(query, limit)

    def _fallback_keyword_search(self, query: str, limit: int) -> str:
        """بحث دلالي محاكى (Simulated Semantic Search) باستخدام تشابه الكلمات."""
        if not os.path.exists(self.lessons_path):
            return "لا توجد خبرات مسجلة."

        from collections import Counter
        import math

        def get_cosine_sim(str1, str2):
            vec1 = Counter(str1.lower().split())
            vec2 = Counter(str2.lower().split())
            intersection = set(vec1.keys()) & set(vec2.keys())
            numerator = sum([vec1[x] * vec2[x] for x in intersection])
            sum1 = sum([vec1[x]**2 for x in vec1.keys()])
            sum2 = sum([vec2[x]**2 for x in vec2.keys()])
            denominator = math.sqrt(sum1) * math.sqrt(sum2)
            if not denominator: return 0.0
            return float(numerator) / denominator

        lessons = []
        with open(self.lessons_path, "r", encoding="utf-8") as f:
            for line in f:
                lessons.append(json.loads(line))

        # حساب التشابه لكل درس
        scored_lessons = []
        for l in lessons:
            content = f"{l['task']} {l['lesson']}"
            score = get_cosine_sim(query, content)
            scored_lessons.append((score, l['lesson']))

        # ترتيب حسب الأعلى تشابهاً
        scored_lessons.sort(key=lambda x: x[0], reverse=True)

        relevant = [l for score, l in scored_lessons if score > 0][:limit]

        if not relevant:
            # إذا لم يجد تشابهاً، يعيد آخر الدروس
            relevant = [l['lesson'] for l in lessons[-limit:]]

        return "\n---\n".join(relevant)

    def record_proposal(self, name: str, code: str, description: str):
        """تسجيل اقتراح تطوري جديد (ناتج عن وضع الأحلام)."""
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        proposal_id = f"prop_{int(datetime.datetime.now().timestamp())}"

        entry = {
            "id": proposal_id,
            "timestamp": timestamp,
            "name": name,
            "description": description,
            "status": "pending"
        }

        # 1. حفظ في سجل المقترحات
        with open(self.proposals_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")

        # 2. حفظ الكود المطور في ملف منفصل
        code_path = os.path.join(self.proposals_dir, f"{proposal_id}.py")
        with open(code_path, "w", encoding="utf-8") as f:
            f.write(code)

        print(f"💡 [Memory] تم تسجيل اقتراح تطوري جديد: {name}")

    def get_pending_proposals(self) -> List[Dict[str, Any]]:
        """استرجاع المقترحات التي تنتظر المراجعة."""
        if not os.path.exists(self.proposals_path):
            return []

        proposals = []
        with open(self.proposals_path, "r", encoding="utf-8") as f:
            for line in f:
                prop = json.loads(line)
                if prop["status"] == "pending":
                    # إضافة الكود للاقتراح
                    code_path = os.path.join(self.proposals_dir, f"{prop['id']}.py")
                    if os.path.exists(code_path):
                        with open(code_path, "r", encoding="utf-8") as cf:
                            prop["code"] = cf.read()
                    proposals.append(prop)
        return proposals

    def update_proposal_status(self, proposal_id: str, status: str):
        """تحديث حالة الاقتراح (مثلاً: accepted أو rejected)."""
        if not os.path.exists(self.proposals_path):
            return

        proposals = []
        with open(self.proposals_path, "r", encoding="utf-8") as f:
            for line in f:
                prop = json.loads(line)
                if prop["id"] == proposal_id:
                    prop["status"] = status
                proposals.append(prop)

        with open(self.proposals_path, "w", encoding="utf-8") as f:
            for prop in proposals:
                f.write(json.dumps(prop, ensure_ascii=False) + "\n")

    def crystallize_skill(self, name: str, code: str, purpose: str):
        """حفظ مهارة متبلورة (كود قابل لإعادة الاستخدام)."""
        skill_data = {
            "name": name,
            "purpose": purpose,
            "code": code,
            "timestamp": str(datetime.datetime.now())
        }
        skill_path = os.path.join(self.memory_dir, "skills", f"{name}.json")
        os.makedirs(os.path.dirname(skill_path), exist_ok=True)
        with open(skill_path, "w", encoding="utf-8") as f:
            json.dump(skill_data, f, ensure_ascii=False, indent=4)
        print(f"💎 [Memory] تبلور مهارة: {name}")

    def update_user_relationship(self, sentiment: str, user_msg: str):
        """تحديث ذاكرة العلاقة مع المستخدم بناءً على التفاعل الأخير."""
        relationship = self.get_user_relationship()

        # تحديث الحالة الوجدانية الأخيرة
        relationship["last_sentiment"] = sentiment
        relationship["interaction_count"] += 1
        relationship["last_interaction"] = str(datetime.datetime.now())

        # رصد التفضيلات (بشكل مبسط)
        if "أفضل" in user_msg or "prefer" in user_msg.lower():
            relationship["preferences"].append(user_msg)

        with open(self.relationship_path, "w", encoding="utf-8") as f:
            json.dump(relationship, f, ensure_ascii=False, indent=4)

    def get_user_relationship(self) -> Dict[str, Any]:
        """استرجاع بيانات العلاقة مع المستخدم."""
        if os.path.exists(self.relationship_path):
            with open(self.relationship_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {
            "last_sentiment": "casual",
            "interaction_count": 0,
            "last_interaction": None,
            "preferences": [],
            "trust_score": 1.0
        }
